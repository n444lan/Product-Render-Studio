import bpy
from bpy.props import (BoolProperty, EnumProperty, FloatProperty, FloatVectorProperty, IntProperty,
                       PointerProperty, StringProperty)
from . import core
from .presets import (PRODUCT_ANIMS, CAMERA_ANIMS, LIGHT_PRESETS, COMP_LOOKS, SHOTS, ASPECTS, FINISHES, RECIPES,
                      TONES, grouped_items, by_id)

PATH_OPTS = {"PATH_SUPPORTS_BLEND_RELATIVE"} if bpy.app.version >= (4, 5, 0) else set()
LIGHT_ITEMS = grouped_items(LIGHT_PRESETS)
PRODUCT_ITEMS = grouped_items(PRODUCT_ANIMS)
CAMERA_ITEMS = grouped_items(CAMERA_ANIMS)
LOOK_ITEMS = grouped_items(COMP_LOOKS)
SHOT_ITEMS = [(r[0], r[1], "", i) for i, r in enumerate(SHOTS)]
ASPECT_ITEMS = [(r[0], r[1], "", i) for i, r in enumerate(ASPECTS)]
FINISH_ITEMS = [(r[0], r[1], "", i) for i, r in enumerate(FINISHES)]
RECIPE_ITEMS = [(r[0], r[1], "", i) for i, r in enumerate(RECIPES)]
TONE_ITEMS = [(t[0], t[1], t[2], i) for i, t in enumerate(TONES)]
GLARE_ITEMS = [
    ("NONE", "Off", "", 0),
    ("BLOOM", "Bloom", "", 1),
    ("FOG_GLOW", "Fog Glow", "", 2),
    ("STREAKS", "Streaks", "", 3),
    ("SIMPLE_STAR", "Star", "", 4),
    ("GHOSTS", "Ghosts", "", 5),
]


def populate_light(p):
    row = by_id(LIGHT_PRESETS, p.light_preset)
    with core.locked():
        p.world_color = tuple(core.hex_rgb(row[3]))
        p.world_strength = row[4]


def populate_shot(p):
    row = by_id(SHOTS, p.shot)
    _, _, az, el, lens, pad, roll, aim, macro, fstop = row
    with core.locked():
        p.focal_length = lens
        p.frame_padding = pad
        p.cam_roll = roll
        p.aim_height = aim
        p.cam_tilt = 0.0
        if fstop is not None:
            p.use_dof = True
            p.dof_auto = True
            p.fstop = fstop
            p.focus_offset = 0.0
        elif p.dof_auto:
            p.use_dof = False
            p.dof_auto = False


def populate_look(p):
    d = by_id(COMP_LOOKS, p.comp_look)[3]
    with core.locked():
        p.comp_glare_type = d["glare"]
        p.comp_glare_strength = d["gs"]
        p.comp_glare_threshold = d["gt"]
        p.comp_glare_size = d["gz"]
        p.comp_streaks = d["streaks"]
        p.comp_streak_angle = d["angle"]
        p.comp_chroma = d["ch"]
        p.comp_vignette = d["vig"]
        p.comp_saturation = d["sat"]
        p.comp_contrast = d["con"]
        p.comp_brightness = d["bri"]
        p.comp_lift = d["lift"]
        p.comp_gamma = d["gamma"]
        p.comp_gain = d["gain"]
        p.comp_sharpen = d["sharp"]
        p.comp_tone = d["tone"]
        p.comp_exposure = d["exp"]


def populate_finish(p):
    with core.locked():
        p.floor_roughness = by_id(FINISHES, p.floor_finish)[2]


def guard(fn):
    def wrapper(self, context):
        if core.is_locked():
            return
        scene = self.id_data
        with core.locked():
            fn(scene, self)
        core.tag_redraw()
    return wrapper


@guard
def up_studio(scene, p):
    from . import studio, lighting
    if core.first(scene, "stage") is not None:
        studio.build_studio(scene)
    if core.first(scene, "light_rig") is not None:
        lighting.update_lights(scene)


@guard
def up_studio_values(scene, p):
    from . import studio
    studio.update_studio_values(scene)


@guard
def up_stage_transform(scene, p):
    from . import studio
    studio.update_stage_transform(scene)


@guard
def up_finish(scene, p):
    from . import studio
    populate_finish(p)
    if core.first(scene, "stage") is not None:
        studio.build_studio(scene)


@guard
def up_podium(scene, p):
    from . import studio, lighting, camera
    if core.first(scene, "stage") is not None:
        studio.build_studio(scene)
    if core.first(scene, "light_rig") is not None:
        lighting.update_lights(scene)
    if core.first(scene, "camera") is not None:
        camera.apply_camera(scene)


@guard
def up_lock_studio(scene, p):
    from . import studio
    for o in core.tagged(scene, *studio.STAGE_ROLES):
        if o.type == "MESH":
            o.hide_select = p.lock_studio


@guard
def up_world_rebuild(scene, p):
    from . import studio
    if scene.world is not None and scene.world.name.startswith("SR World"):
        studio.build_world(scene)


@guard
def up_world_values(scene, p):
    from . import studio
    studio.update_world_values(scene)


@guard
def up_light_preset(scene, p):
    from . import lighting
    populate_light(p)
    if core.first(scene, "light_rig") is not None:
        lighting.build_lights(scene)


@guard
def up_flags(scene, p):
    from . import lighting
    lighting.refresh_flags(scene)


@guard
def up_lights(scene, p):
    from . import lighting
    lighting.update_lights(scene)


@guard
def up_shot(scene, p):
    from . import camera
    populate_shot(p)
    if core.first(scene, "camera") is not None:
        camera.apply_camera(scene)


@guard
def up_camera(scene, p):
    from . import camera
    if core.first(scene, "camera") is not None:
        camera.apply_camera(scene)


@guard
def up_dof(scene, p):
    from . import camera
    p.dof_auto = False
    if core.first(scene, "camera") is not None:
        camera.apply_camera(scene)


@guard
def up_aspect(scene, p):
    from . import render, camera, studio, look
    render.apply_resolution(scene)
    if core.first(scene, "camera") is not None:
        camera.apply_camera(scene)
    studio.update_studio_values(scene)
    studio.update_world_values(scene)
    look.update(scene)


@guard
def up_product_anim(scene, p):
    from . import animation
    if p.auto_apply:
        animation.apply_product_anim(scene)


@guard
def up_camera_anim(scene, p):
    from . import animation
    if p.auto_apply:
        animation.apply_camera_anim(scene)


@guard
def up_anims(scene, p):
    from . import animation
    if p.auto_apply:
        animation.apply_all(scene)


@guard
def up_timing(scene, p):
    from . import render, animation
    render.apply_timing(scene)
    if p.auto_apply:
        animation.apply_all(scene)


@guard
def up_film(scene, p):
    from . import render, look
    render.apply_film(scene)
    render.apply_output(scene)
    if p.use_look and look.is_ours(scene):
        look.build(scene)


@guard
def up_engine(scene, p):
    from . import render
    render.apply_engine(scene)


@guard
def up_quality(scene, p):
    from . import render, look
    render.apply_quality(scene)
    look.update(scene)


@guard
def up_output(scene, p):
    from . import render
    render.apply_output(scene)


@guard
def up_look_preset(scene, p):
    from . import look
    populate_look(p)
    if p.use_look:
        if not look.is_ours(scene):
            look.build(scene)
            look.attach(scene, True)
        else:
            look.update(scene)
    else:
        look.color_management(scene)


@guard
def up_look_values(scene, p):
    from . import look
    if p.use_look and look.is_ours(scene):
        look.update(scene)
    else:
        look.color_management(scene)


@guard
def up_use_look(scene, p):
    from . import look
    look.apply(scene)


class SR_Props(bpy.types.PropertyGroup):
    product_root: PointerProperty(type=bpy.types.Object, name="Product")
    prod_w: FloatProperty(default=0.0)
    prod_d: FloatProperty(default=0.0)
    prod_h: FloatProperty(default=0.0)
    prev_world: StringProperty()
    prev_comp: StringProperty()

    prep_ground: BoolProperty(name="Sit on Floor", default=True, description="Move the product so its lowest point rests on the floor")
    prep_center: BoolProperty(name="Center at Origin", default=True, description="Center the product footprint on the world origin")
    prep_apply_scale: BoolProperty(name="Apply Scale", default=False, description="Bake object scale into mesh data for accurate bevels and depth of field")
    prep_smooth: BoolProperty(name="Smooth Shading", default=False, description="Set smooth shading on all product meshes")
    prep_normalize: BoolProperty(name="Normalize Size", default=False, description="Rescale the product so its largest dimension matches Target Size (useful for CAD imports in millimetres)")
    prep_size: FloatProperty(name="Target Size", default=0.3, min=0.001, soft_max=10.0, unit="LENGTH")

    recipe: EnumProperty(name="Recipe", items=RECIPE_ITEMS, description="Complete art-direction preset: backdrop, floor, lighting, shot and grade")

    backdrop_type: EnumProperty(name="Backdrop", items=[
        ("CYC", "Cyclorama", "Curved infinity sweep sized to the product", "MESH_PLANE", 0),
        ("DOME", "360 Studio", "Seamless dome and floor for orbits and turntables", "MESH_UVSPHERE", 1),
        ("IMAGE", "Image Background", "Image locked to the camera with a shadow-catching floor", "IMAGE_DATA", 2),
        ("NONE", "None", "Lighting and world only", "BLANK1", 3),
    ], default="CYC", update=up_studio)
    backdrop_scale: FloatProperty(name="Studio Size", default=1.0, min=0.2, soft_max=5.0, update=up_studio)
    cyc_curve: FloatProperty(name="Sweep Curve", default=0.4, min=0.05, max=1.0, update=up_studio)
    cyc_face_camera: BoolProperty(name="Face Camera", default=True, update=up_stage_transform)
    backdrop_rotation: FloatProperty(name="Rotation", default=0.0, subtype="ANGLE", unit="ROTATION", update=up_stage_transform)
    gradient_type: EnumProperty(name="Gradient", items=[
        ("SOLID", "Solid", "", 0),
        ("SCREEN", "Spotlight (Frame)", "Radial glow centred in the frame", 1),
        ("VERTICAL", "Vertical", "Floor to ceiling", 2),
        ("RADIAL", "Radial Pool", "Pool of light around the product", 3),
        ("HORIZONTAL", "Horizontal", "Side to side", 4),
    ], default="SCREEN", update=up_studio)
    color_a: FloatVectorProperty(name="Outer / Top", subtype="COLOR", size=3, min=0.0, max=1.0, default=(0.06, 0.06, 0.065), update=up_studio_values)
    color_b: FloatVectorProperty(name="Inner / Bottom", subtype="COLOR", size=3, min=0.0, max=1.0, default=(0.42, 0.42, 0.44), update=up_studio_values)
    gradient_position: FloatProperty(name="Position", default=0.55, min=-1.0, max=2.0, update=up_studio_values)
    gradient_softness: FloatProperty(name="Softness", default=0.9, min=0.0, max=3.0, update=up_studio_values)
    backdrop_glow: FloatProperty(name="Backdrop Glow", default=0.0, min=0.0, soft_max=3.0, update=up_studio_values, description="Self-illumination of the backdrop")
    floor_finish: EnumProperty(name="Floor Finish", items=FINISH_ITEMS, default="SATIN", update=up_finish)
    floor_roughness: FloatProperty(name="Roughness", default=0.38, min=0.0, max=1.0, update=up_studio_values)
    podium_type: EnumProperty(name="Podium", items=[
        ("NONE", "None", "", 0),
        ("CYLINDER", "Cylinder", "", 1),
        ("BOX", "Box", "", 2),
        ("ROUNDED", "Rounded Box", "", 3),
        ("HEX", "Hexagon", "", 4),
        ("STEPPED", "Stepped", "", 5),
    ], default="NONE", update=up_podium)
    podium_height: FloatProperty(name="Height", default=0.5, min=0.02, soft_max=3.0, update=up_podium)
    podium_padding: FloatProperty(name="Padding", default=0.35, min=0.0, soft_max=3.0, update=up_podium)
    podium_color: FloatVectorProperty(name="Colour", subtype="COLOR", size=3, min=0.0, max=1.0, default=(0.8, 0.8, 0.8), update=up_studio_values)
    podium_finish: EnumProperty(name="Finish", items=FINISH_ITEMS, default="MATTE", update=up_podium)
    image_path: StringProperty(name="Image", subtype="FILE_PATH", options=PATH_OPTS, update=up_studio)
    image_fit: EnumProperty(name="Fit", items=[("FILL", "Fill", "", 0), ("FIT", "Fit", "", 1), ("STRETCH", "Stretch", "", 2)], update=up_world_values)
    image_strength: FloatProperty(name="Brightness", default=1.0, min=0.0, soft_max=4.0, update=up_world_values)
    image_light: BoolProperty(name="Light With Image", default=False, update=up_world_rebuild)
    image_floor: EnumProperty(name="Floor", items=[("SHADOW", "Shadow Catcher", "Cycles only", 0), ("NONE", "None", "", 1)], update=up_studio)
    lock_studio: BoolProperty(name="Lock Studio Selection", default=True, update=up_lock_studio)

    light_preset: EnumProperty(name="Lighting", items=LIGHT_ITEMS, default="THREE_POINT", update=up_light_preset)
    light_intensity: FloatProperty(name="Intensity", default=1.0, min=0.0, soft_max=5.0, update=up_lights)
    light_temperature: FloatProperty(name="Temperature Shift", default=0.0, min=-4500.0, max=6000.0, update=up_lights, description="Warm (negative) or cool (positive) shift in Kelvin")
    light_rotation: FloatProperty(name="Rotate Rig", default=0.0, subtype="ANGLE", unit="ROTATION", update=up_lights)
    light_size: FloatProperty(name="Softness", default=1.0, min=0.05, soft_max=4.0, update=up_lights, description="Scales light sizes")
    light_distance: FloatProperty(name="Distance", default=1.0, min=0.3, soft_max=3.0, update=up_lights)
    flag_backlights: BoolProperty(name="Flag Backlights From Floor", default=True, update=up_flags, description="Stop lights behind the product from lighting or reflecting in the backdrop, like a photographer's flag")
    light_follow_camera: BoolProperty(name="Follow Camera", default=True, update=up_lights, description="Keep the rig oriented to the camera's shot angle")
    world_color: FloatVectorProperty(name="Ambient", subtype="COLOR", size=3, min=0.0, max=1.0, default=(0.01, 0.01, 0.01), update=up_world_values)
    world_strength: FloatProperty(name="Ambient Strength", default=0.15, min=0.0, soft_max=3.0, update=up_world_values)
    hdri_path: StringProperty(name="HDRI", subtype="FILE_PATH", options=PATH_OPTS, update=up_world_rebuild, description="Optional environment map for reflections")
    hdri_rotation: FloatProperty(name="HDRI Rotation", default=0.0, min=-360.0, max=360.0, update=up_world_values)
    hdri_hide: BoolProperty(name="Hide From Camera", default=True, update=up_world_rebuild)

    shot: EnumProperty(name="Shot", items=SHOT_ITEMS, default="HERO", update=up_shot)
    focal_length: FloatProperty(name="Lens", default=65.0, min=8.0, soft_max=300.0, unit="CAMERA", update=up_camera)
    frame_padding: FloatProperty(name="Padding", default=0.16, min=-0.8, soft_max=2.0, update=up_camera, description="Space around the product; negative values crop in")
    cam_azimuth: FloatProperty(name="Orbit", default=0.0, min=-180.0, max=180.0, update=up_camera)
    cam_elevation: FloatProperty(name="Height", default=0.0, min=-60.0, max=75.0, update=up_camera)
    cam_roll: FloatProperty(name="Roll", default=0.0, min=-45.0, max=45.0, update=up_camera)
    cam_tilt: FloatProperty(name="Tilt", default=0.0, min=-30.0, max=30.0, update=up_camera)
    aim_height: FloatProperty(name="Aim Height", default=0.5, min=0.0, max=1.0, update=up_camera)
    frame_offset_x: FloatProperty(name="Offset X", default=0.0, min=-1.0, max=1.0, update=up_camera)
    frame_offset_y: FloatProperty(name="Offset Y", default=0.0, min=-1.0, max=1.0, update=up_camera)
    macro_zoom: FloatProperty(name="Macro Zoom", default=0.45, min=0.05, max=1.0, update=up_camera, description="Lower values push closer on the detail")
    use_dof: BoolProperty(name="Depth of Field", default=False, update=up_dof)
    dof_auto: BoolProperty(default=False)
    fstop: FloatProperty(name="f-stop", default=4.0, min=0.5, soft_max=22.0, update=up_camera)
    focus_offset: FloatProperty(name="Focus Offset", default=0.0, min=-3.0, max=3.0, update=up_camera, description="Shift focus toward (negative) or away from (positive) the camera")
    aspect: EnumProperty(name="Aspect", items=ASPECT_ITEMS, default="16_9", update=up_aspect)
    resolution: EnumProperty(name="Resolution", items=[
        ("720", "720p", "", 0), ("1080", "1080p", "", 1), ("1440", "1440p", "", 2), ("2160", "4K", "", 3),
    ], default="1080", update=up_aspect)
    show_thirds: BoolProperty(name="Thirds Guide", default=True, update=up_camera)

    product_anim: EnumProperty(name="Product", items=PRODUCT_ITEMS, default="NONE", update=up_product_anim)
    camera_anim: EnumProperty(name="Camera", items=CAMERA_ITEMS, default="STATIC", update=up_camera_anim)
    anim_strength: FloatProperty(name="Product Amount", default=1.0, min=0.0, soft_max=3.0, update=up_product_anim)
    cam_anim_strength: FloatProperty(name="Camera Amount", default=1.0, min=0.0, soft_max=3.0, update=up_camera_anim)
    fps: EnumProperty(name="FPS", items=[("24", "24", "", 0), ("25", "25", "", 1), ("30", "30", "", 2), ("50", "50", "", 3), ("60", "60", "", 4)], default="30", update=up_timing)
    duration: FloatProperty(name="Duration", default=6.0, min=0.2, soft_max=60.0, unit="TIME_ABSOLUTE", update=up_timing)
    hold_start: IntProperty(name="Hold In", default=0, min=0, soft_max=120, update=up_anims, description="Frames to hold before motion starts")
    hold_end: IntProperty(name="Hold Out", default=0, min=0, soft_max=120, update=up_anims, description="Frames to hold after motion ends")
    seamless_loop: BoolProperty(name="Seamless Loop", default=True, update=up_anims, description="Loop presets finish one frame past the end so the clip repeats without a duplicate frame")
    auto_apply: BoolProperty(name="Live Apply", default=True, description="Apply animation presets as soon as they are picked")
    motion_blur: BoolProperty(name="Motion Blur", default=False, update=up_film)
    shutter: FloatProperty(name="Shutter", default=0.5, min=0.01, max=2.0, update=up_film)

    use_look: BoolProperty(name="Use Compositing", default=True, update=up_use_look)
    comp_look: EnumProperty(name="Look", items=LOOK_ITEMS, default="CLEAN_COMMERCIAL", update=up_look_preset)
    comp_intensity: FloatProperty(name="Look Intensity", default=1.0, min=0.0, soft_max=2.0, update=up_look_values)
    comp_glare_type: EnumProperty(name="Glare", items=GLARE_ITEMS, default="BLOOM", update=up_look_values)
    comp_glare_strength: FloatProperty(name="Strength", default=0.15, min=0.0, soft_max=1.5, update=up_look_values)
    comp_glare_threshold: FloatProperty(name="Threshold", default=1.0, min=0.0, soft_max=4.0, update=up_look_values)
    comp_glare_size: FloatProperty(name="Size", default=0.5, min=0.0, max=1.0, update=up_look_values)
    comp_streaks: IntProperty(name="Streaks", default=4, min=1, max=16, update=up_look_values)
    comp_streak_angle: FloatProperty(name="Streak Angle", default=0.0, min=-180.0, max=180.0, update=up_look_values)
    comp_chroma: FloatProperty(name="Chromatic Aberration", default=0.0, min=0.0, soft_max=0.05, max=1.0, precision=3, update=up_look_values)
    comp_vignette: FloatProperty(name="Vignette", default=0.1, min=0.0, max=1.0, update=up_look_values)
    comp_saturation: FloatProperty(name="Saturation", default=1.05, min=0.0, soft_max=2.0, update=up_look_values)
    comp_contrast: FloatProperty(name="Contrast", default=5.0, min=-100.0, max=100.0, soft_min=-40.0, soft_max=40.0, update=up_look_values)
    comp_brightness: FloatProperty(name="Brightness", default=0.0, min=-100.0, max=100.0, soft_min=-30.0, soft_max=30.0, update=up_look_values)
    comp_lift: FloatVectorProperty(name="Lift", subtype="COLOR_GAMMA", size=3, min=0.0, soft_max=1.3, default=(1.0, 1.0, 1.0), update=up_look_values)
    comp_gamma: FloatVectorProperty(name="Gamma", subtype="COLOR_GAMMA", size=3, min=0.0, soft_max=1.3, default=(1.0, 1.0, 1.0), update=up_look_values)
    comp_gain: FloatVectorProperty(name="Gain", subtype="COLOR_GAMMA", size=3, min=0.0, soft_max=1.3, default=(1.0, 1.0, 1.0), update=up_look_values)
    comp_sharpen: FloatProperty(name="Sharpen", default=0.1, min=0.0, max=1.0, update=up_look_values)
    comp_tone: EnumProperty(name="Tone", items=TONE_ITEMS, default="AgX - Base Contrast", update=up_look_values)
    comp_exposure: FloatProperty(name="Exposure", default=0.0, min=-6.0, max=6.0, update=up_look_values)

    engine: EnumProperty(name="Engine", items=[("CYCLES", "Cycles", "", 0), ("EEVEE", "EEVEE", "", 1)], default="CYCLES", update=up_engine)
    quality: EnumProperty(name="Quality", items=[
        ("DRAFT", "Draft", "Half resolution, low samples", 0),
        ("PREVIEW", "Preview", "", 1),
        ("FINAL", "Final", "", 2),
        ("ULTRA", "Ultra", "", 3),
    ], default="PREVIEW", update=up_quality)
    film_transparent: BoolProperty(name="Transparent Background", default=False, update=up_film)
    output_format: EnumProperty(name="Format", items=[
        ("MP4", "MP4 Video", "H.264", 0), ("PNG", "PNG Sequence", "", 1), ("JPEG", "JPEG Sequence", "", 2),
    ], default="MP4", update=up_output)
    output_dir: StringProperty(name="Folder", subtype="DIR_PATH", default="//renders/", options=PATH_OPTS, update=up_output)
    output_name: StringProperty(name="Name", default="product", update=up_output)


def register():
    bpy.utils.register_class(SR_Props)
    bpy.types.Scene.studio_reel = PointerProperty(type=SR_Props)


def unregister():
    del bpy.types.Scene.studio_reel
    bpy.utils.unregister_class(SR_Props)
