import bpy
import math
from . import core
from .core import P, put
from .presets import GLARE_NAMES

TREE_NAME = "SR Look"


def tree(scene, create=True):
    if core.V5:
        ng = bpy.data.node_groups.get(TREE_NAME)
        if ng is None and create:
            ng = bpy.data.node_groups.new(TREE_NAME, "CompositorNodeTree")
        return ng
    if create:
        scene.use_nodes = True
    return scene.node_tree


def attach(scene, enable):
    p = P(scene)
    if core.V5:
        cur = scene.compositing_node_group
        if enable:
            ng = tree(scene, True)
            if cur is not ng:
                if cur is not None:
                    p.prev_comp = cur.name
                scene.compositing_node_group = ng
        else:
            ng = bpy.data.node_groups.get(TREE_NAME)
            if cur is not None and cur is ng:
                prev = bpy.data.node_groups.get(p.prev_comp) if p.prev_comp else None
                scene.compositing_node_group = prev
    elif enable:
        scene.use_nodes = True
    elif is_ours(scene):
        scene.use_nodes = False
    scene.render.use_compositing = True


def is_ours(scene):
    t = tree(scene, False)
    return t is not None and "SR_Glare" in t.nodes


def mix_multiply(t, loc):
    try:
        n = t.nodes.new("CompositorNodeMixRGB")
        n.blend_type = "MULTIPLY"
        n.location = loc
        return n, n.inputs[0], n.inputs[1], n.inputs[2], n.outputs[0]
    except RuntimeError:
        n = t.nodes.new("ShaderNodeMix")
        n.data_type = "RGBA"
        n.blend_type = "MULTIPLY"
        n.location = loc
        return n, n.inputs[0], n.inputs[6], n.inputs[7], n.outputs[2]


def add(t, kind, name, x, y=0):
    n = t.nodes.new(kind)
    n.name = name
    n.label = name.replace("SR_", "")
    n.location = (x, y)
    return n


def build(scene):
    t = tree(scene, True)
    t.nodes.clear()
    rl = add(t, "CompositorNodeRLayers", "SR_Render", -200)
    if hasattr(rl, "scene"):
        rl.scene = scene
    glare = add(t, "CompositorNodeGlare", "SR_Glare", 100)
    lens = add(t, "CompositorNodeLensdist", "SR_Chroma", 350)
    cb = add(t, "CompositorNodeColorBalance", "SR_Grade", 600)
    hs = add(t, "CompositorNodeHueSat", "SR_Saturation", 850)
    bc = add(t, "CompositorNodeBrightContrast", "SR_Contrast", 1100)
    sh = add(t, "CompositorNodeFilter", "SR_Sharpen", 1350)
    vm, vfac, va, vb, vout = mix_multiply(t, (1600, 0))
    vm.name = "SR_Vignette"
    vm.label = "Vignette"
    el = add(t, "CompositorNodeEllipseMask", "SR_VigMask", 1100, -350)
    bl = add(t, "CompositorNodeBlur", "SR_VigBlur", 1350, -350)
    link = t.links.new
    link(rl.outputs["Image"], glare.inputs["Image"])
    link(core.out_sock(glare, "Image"), lens.inputs["Image"])
    link(lens.outputs["Image"], core.find_in(cb, "Image"))
    link(cb.outputs["Image"], core.find_in(hs, "Image"))
    link(hs.outputs["Image"], core.find_in(bc, "Image"))
    link(bc.outputs["Image"], core.find_in(sh, "Image"))
    link(sh.outputs["Image"], va)
    link(core.out_sock(el, "Mask"), bl.inputs["Image"])
    link(bl.outputs["Image"], vb)
    last = vout
    if scene.render.film_transparent:
        sa = add(t, "CompositorNodeSetAlpha", "SR_Alpha", 1850)
        put(sa, "Type", "Replace Alpha", "mode", "REPLACE_ALPHA")
        link(last, core.find_in(sa, "Image"))
        link(rl.outputs["Alpha"], core.find_in(sa, "Alpha"))
        last = sa.outputs["Image"]
    if core.V5:
        if not any(getattr(i, "in_out", None) == "OUTPUT" for i in t.interface.items_tree):
            t.interface.new_socket("Image", in_out="OUTPUT", socket_type="NodeSocketColor")
        out = add(t, "NodeGroupOutput", "SR_Output", 2100)
        link(last, out.inputs[0])
    else:
        out = add(t, "CompositorNodeComposite", "SR_Output", 2100)
        link(last, out.inputs["Image"])
    view = add(t, "CompositorNodeViewer", "SR_Viewer", 2100, -200)
    link(last, view.inputs[0])
    put(cb, "Type", "Lift/Gamma/Gain", "correction_method", "LIFT_GAMMA_GAIN")
    put(lens, "Type", "Radial", "distortion_type", "RADIAL")
    put(lens, "Distortion", 0.0)
    put(lens, "Jitter", False, "use_jitter", False)
    put(lens, "Fit", False, "use_fit", False)
    put(sh, "Type", "Box Sharpen", "filter_type", "SHARPEN")
    put(bl, "Type", "Fast Gaussian", "filter_type", "FAST_GAUSS")
    sock = core.find_in(el, "Position")
    if sock is not None:
        sock.default_value = (0.5, 0.5)
    else:
        el.x = 0.5
        el.y = 0.5
    put(el, "Mask", 0.0)
    put(el, "Value", 1.0)
    update(scene)
    return t


def blend(v, neutral, k):
    if isinstance(v, (tuple, list)) or hasattr(v, "__len__"):
        return tuple(neutral + (c - neutral) * k for c in v)
    return neutral + (v - neutral) * k


def update(scene):
    p = P(scene)
    t = tree(scene, False)
    if t is None or "SR_Glare" not in t.nodes:
        return
    n = t.nodes
    k = p.comp_intensity
    g = n["SR_Glare"]
    gt = p.comp_glare_type
    g.mute = gt == "NONE" or p.comp_glare_strength * k <= 1e-4
    if gt != "NONE":
        put(g, "Type", GLARE_NAMES[gt], "glare_type", gt)
        put(g, "Quality", "Medium", "quality", "MEDIUM")
        s = p.comp_glare_strength * k
        put(g, "Strength", s, "mix", max(-1.0, min(1.0, -1.0 + s)))
        put(g, ("Highlights Threshold", "Threshold"), p.comp_glare_threshold, "threshold", p.comp_glare_threshold)
        put(g, "Size", p.comp_glare_size, "size", int(round(6 + p.comp_glare_size * 3)))
        put(g, "Streaks", p.comp_streaks, "streaks", p.comp_streaks)
        put(g, "Streaks Angle", math.radians(p.comp_streak_angle), "angle_offset", math.radians(p.comp_streak_angle))
        put(g, "Fade", 0.92, "fade", 0.92)
    lens = n["SR_Chroma"]
    ch = p.comp_chroma * k
    lens.mute = ch <= 1e-5
    put(lens, "Dispersion", ch)
    cb = n["SR_Grade"]
    put(cb, ("Color Lift", "Lift"), blend(p.comp_lift, 1.0, k), "lift", blend(p.comp_lift, 1.0, k))
    put(cb, ("Color Gamma", "Gamma"), blend(p.comp_gamma, 1.0, k), "gamma", blend(p.comp_gamma, 1.0, k))
    put(cb, ("Color Gain", "Gain"), blend(p.comp_gain, 1.0, k), "gain", blend(p.comp_gain, 1.0, k))
    put(n["SR_Saturation"], "Saturation", blend(p.comp_saturation, 1.0, k))
    put(n["SR_Contrast"], ("Bright", "Brightness"), p.comp_brightness * k)
    put(n["SR_Contrast"], "Contrast", p.comp_contrast * k)
    put(n["SR_Sharpen"], ("Fac", "Factor"), min(1.0, p.comp_sharpen * k * 0.15))
    vm = n["SR_Vignette"]
    put(vm, ("Fac", "Factor"), min(1.0, p.comp_vignette * k))
    r = scene.render
    px = max(1, int(min(r.resolution_x, r.resolution_y) * r.resolution_percentage / 100 * 0.28))
    bl = n["SR_VigBlur"]
    sock = core.find_in(bl, "Size")
    if sock is not None and sock.type == "VECTOR":
        sock.default_value = (px, px)
    elif hasattr(bl, "size_x"):
        bl.size_x = px
        bl.size_y = px
    el = n["SR_VigMask"]
    sock = core.find_in(el, "Size")
    if sock is not None:
        sock.default_value = (1.25, 1.25)
    else:
        el.mask_width = 1.25
        el.mask_height = 1.25
    color_management(scene)


def color_management(scene):
    p = P(scene)
    vs = scene.view_settings
    try:
        vs.view_transform = "AgX"
    except TypeError:
        return
    try:
        vs.look = p.comp_tone
    except TypeError:
        vs.look = "None"
    vs.exposure = p.comp_exposure


def apply(scene):
    p = P(scene)
    if p.use_look:
        build(scene)
        attach(scene, True)
    else:
        attach(scene, False)
        color_management(scene)
