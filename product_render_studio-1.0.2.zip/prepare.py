import bpy
import math
from mathutils import Vector, Matrix
from . import core
from .core import P

PART_ROLES = ("product_root", "product_motion", "product_spin", "product_align")


def parts(scene):
    root = core.product_root(scene)
    if root is None:
        return None, None, None, None
    found = {r: None for r in PART_ROLES}
    stack = [root]
    while stack:
        o = stack.pop()
        role = o.get("sr_role")
        if role in found and found[role] is None:
            found[role] = o
        stack.extend(o.children)
    return root, found["product_motion"], found["product_spin"], found["product_align"]


def product_objects(scene):
    root, motion, spin, align = parts(scene)
    if align is None:
        return []
    return list(align.children)


def gather(objs):
    out = []
    seen = set()
    stack = list(objs)
    while stack:
        o = stack.pop()
        if o.name in seen:
            continue
        seen.add(o.name)
        out.append(o)
        stack.extend(o.children)
    return out


def release(scene):
    root, motion, spin, align = parts(scene)
    if root is None:
        return 0
    bpy.context.view_layer.update()
    kids = list(align.children) if align is not None else []
    for o in kids:
        mw = o.matrix_world.copy()
        o.parent = None
        o.matrix_world = mw
    for o in (align, spin, motion, root):
        if o is not None:
            core.clear_anim(o)
            bpy.data.objects.remove(o, do_unlink=True)
    P(scene).product_root = None
    return len(kids)


def prepare(context, objs):
    scene = context.scene
    p = P(scene)
    objs = [o for o in objs if o.get("sr_role") is None]
    if not objs:
        return None
    release(scene)
    names = {o.name for o in objs}
    top = [o for o in objs if o.parent is None or o.parent.name not in names]
    if p.prep_apply_scale:
        for o in top:
            if o.type == "MESH" and o.data.users == 1:
                mw = o.matrix_world.copy()
                loc, rot, sca = mw.decompose()
                o.data.transform(Matrix.Diagonal(sca.to_4d()))
                o.matrix_world = Matrix.LocRotScale(loc, rot, Vector((1, 1, 1)))
                for c in o.children:
                    c.matrix_parent_inverse = Matrix.Diagonal(sca.to_4d()) @ c.matrix_parent_inverse
    if p.prep_smooth:
        for o in gather(top):
            if o.type == "MESH":
                o.data.polygons.foreach_set("use_smooth", [True] * len(o.data.polygons))
                o.data.update()
    context.view_layer.update()
    box = core.world_bbox(gather(top))
    if box is None:
        return None
    mn, mx = box
    base = Vector(((mn.x + mx.x) / 2, (mn.y + mx.y) / 2, mn.z))
    if p.prep_normalize:
        size = max(mx - mn)
        if size > 1e-9:
            s = p.prep_size / size
            m = Matrix.Translation(base) @ Matrix.Scale(s, 4) @ Matrix.Translation(-base)
            for o in top:
                o.matrix_world = m @ o.matrix_world
            context.view_layer.update()
            mn, mx = core.world_bbox(gather(top))
            base = Vector(((mn.x + mx.x) / 2, (mn.y + mx.y) / 2, mn.z))
    shift = Vector((-base.x if p.prep_center else 0.0, -base.y if p.prep_center else 0.0, -base.z if p.prep_ground else 0.0))
    if shift.length > 0:
        t = Matrix.Translation(shift)
        for o in top:
            o.matrix_world = t @ o.matrix_world
        base += shift
        mn += shift
        mx += shift
    dims = mx - mn
    h = max(dims.z, 1e-4)
    R = max(0.5 * dims.length, 1e-3)
    root = core.new_empty(scene, "SR Product", "product_root", "product", "CIRCLE", R * 0.8)
    root.location = base
    motion = core.new_empty(scene, "SR Product Motion", "product_motion", "product", "ARROWS", R * 0.4, root)
    spin = core.new_empty(scene, "SR Product Spin", "product_spin", "product", "SPHERE", R * 0.25, motion)
    spin.location = (0.0, 0.0, h * 0.5)
    align = core.new_empty(scene, "SR Product Align", "product_align", "product", "PLAIN_AXES", R * 0.1, spin)
    align.location = (0.0, 0.0, -h * 0.5)
    align.hide_select = True
    context.view_layer.update()
    inv = align.matrix_world.inverted()
    for o in top:
        mw = o.matrix_world.copy()
        o.parent = align
        o.matrix_parent_inverse = inv
        o.matrix_world = mw
    p.product_root = root
    p.prod_w = max(dims.x, 1e-4)
    p.prod_d = max(dims.y, 1e-4)
    p.prod_h = h
    update_alignment(scene)
    context.view_layer.update()
    return root


def update_alignment(scene):
    root, motion, spin, align = parts(scene)
    if root is None:
        return
    az = math.radians(core.camera_az(scene))
    root.rotation_euler = (0.0, 0.0, az)
    if align is not None:
        align.rotation_euler = (0.0, 0.0, -az)
    if spin is not None:
        spin.location = (0.0, 0.0, P(scene).prod_h * 0.5)
    if align is not None:
        align.location = (0.0, 0.0, -P(scene).prod_h * 0.5)
