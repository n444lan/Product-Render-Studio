import bpy
import math
import os
from . import core
from .core import P, node, link, put
from .presets import FINISHES, by_id

STAGE_ROLES = ("stage", "backdrop", "floor", "podium", "catcher")


def stage_dims(scene):
    p = P(scene)
    info = core.product_info(scene)
    R = info["R"]
    s = p.backdrop_scale
    return {
        "R": R,
        "front": 14 * R * s,
        "offset": 4.5 * R * s,
        "curve": max(0.05, p.cyc_curve) * 6 * R * s,
        "height": 14 * R * s,
        "width": 34 * R * s,
        "dome": 45 * R * s,
        "h": info["h"],
    }


def cyc_mesh(me, d):
    seg = 28
    prof = [(-d["front"], 0.0)]
    steps_floor = 6
    for i in range(1, steps_floor + 1):
        prof.append((-d["front"] + (d["front"] + d["offset"]) * i / steps_floor, 0.0))
    rc = d["curve"]
    for i in range(1, seg + 1):
        a = (math.pi / 2) * i / seg
        prof.append((d["offset"] + rc * math.sin(a), rc - rc * math.cos(a)))
    top = max(d["height"], rc * 1.2)
    for i in range(1, 5):
        prof.append((d["offset"] + rc, rc + (top - rc) * i / 4))
    cols = 12
    verts = []
    for j in range(cols + 1):
        x = -d["width"] / 2 + d["width"] * j / cols
        for y, z in prof:
            verts.append((x, y, z))
    n = len(prof)
    faces = []
    for j in range(cols):
        for i in range(n - 1):
            a = j * n + i
            b = (j + 1) * n + i
            faces.append((a, b, b + 1, a + 1))
    return core.set_mesh(me, verts, faces, smooth=True)


def dome_mesh(me, radius, rings=24, segs=64):
    verts = []
    for r in range(rings):
        phi = (math.pi / 2) * r / rings
        z = radius * math.sin(phi)
        rr = radius * math.cos(phi)
        for s in range(segs):
            t = 2 * math.pi * s / segs
            verts.append((rr * math.cos(t), rr * math.sin(t), z))
    pole = len(verts)
    verts.append((0.0, 0.0, radius))
    faces = []
    for r in range(rings - 1):
        for s in range(segs):
            a = r * segs + s
            b = r * segs + (s + 1) % segs
            faces.append((a, a + segs, b + segs, b))
    o = (rings - 1) * segs
    for s in range(segs):
        faces.append((o + s, pole, o + (s + 1) % segs))
    return core.set_mesh(me, verts, faces, smooth=True)


def disc_mesh(me, radius, z=0.0, segs=96, rings=6):
    verts = [(0.0, 0.0, z)]
    for r in range(1, rings + 1):
        rr = radius * (r / rings) ** 1.6
        for s in range(segs):
            t = 2 * math.pi * s / segs
            verts.append((rr * math.cos(t), rr * math.sin(t), z))
    faces = []
    for s in range(segs):
        faces.append((0, 1 + s, 1 + (s + 1) % segs))
    for r in range(rings - 1):
        o = 1 + r * segs
        for s in range(segs):
            a = o + s
            b = o + (s + 1) % segs
            faces.append((a, a + segs, b + segs, b))
    return core.set_mesh(me, verts, faces, smooth=True)


def prism_mesh(me, n, rx, ry, z0, z1, rot=0.0):
    verts = []
    for z in (z0, z1):
        for i in range(n):
            t = rot + 2 * math.pi * i / n
            verts.append((rx * math.cos(t), ry * math.sin(t), z))
    faces = [tuple(range(n - 1, -1, -1)), tuple(range(n, 2 * n))]
    for i in range(n):
        j = (i + 1) % n
        faces.append((i, j, n + j, n + i))
    return verts, faces


def podium_mesh(me, kind, rx, ry, hgt):
    if kind == "CYLINDER":
        v, f = prism_mesh(me, 96, rx, rx, -hgt, 0.0)
    elif kind == "HEX":
        v, f = prism_mesh(me, 6, rx, rx, -hgt, 0.0, math.pi / 6)
    elif kind in {"BOX", "ROUNDED"}:
        v, f = prism_mesh(me, 4, rx * math.sqrt(2), ry * math.sqrt(2), -hgt, 0.0, math.pi / 4)
    else:
        v1, f1 = prism_mesh(me, 96, rx * 1.35, rx * 1.35, -hgt, -hgt * 0.5)
        v2, f2 = prism_mesh(me, 96, rx, rx, -hgt * 0.5, 0.0)
        o = len(v1)
        v = v1 + v2
        f = f1 + [tuple(i + o for i in face) for face in f2]
    core.set_mesh(me, v, f, smooth=kind in {"CYLINDER", "STEPPED"})


def add_bevel(obj, width, segments=3):
    mod = obj.modifiers.new("SR Bevel", "BEVEL")
    mod.width = width
    mod.segments = segments
    mod.limit_method = "ANGLE"
    try:
        mod.harden_normals = True
    except AttributeError:
        pass
    return mod


def gradient_factor(nt, scene, kind, d, x=-900):
    p = P(scene)
    mode = p.gradient_type
    if mode == "SOLID":
        return None
    tc = node(nt, "ShaderNodeTexCoord", loc=(x, 0))
    if mode == "SCREEN":
        sub = node(nt, "ShaderNodeVectorMath", loc=(x + 180, 0))
        sub.operation = "SUBTRACT"
        link(nt, tc.outputs["Window"], sub.inputs[0])
        sub.inputs[1].default_value = (0.5, 0.42, 0.0)
        mul = node(nt, "ShaderNodeVectorMath", "SR_Aspect", (x + 360, 0))
        mul.operation = "MULTIPLY"
        link(nt, sub.outputs[0], mul.inputs[0])
        mul.inputs[1].default_value = (aspect(scene) * 1.4, 1.4, 0.0)
        ln = node(nt, "ShaderNodeVectorMath", loc=(x + 540, 0))
        ln.operation = "LENGTH"
        link(nt, mul.outputs[0], ln.inputs[0])
        fac = out_value(ln)
    elif mode == "VERTICAL":
        sep = node(nt, "ShaderNodeSeparateXYZ", loc=(x + 180, 0))
        link(nt, tc.outputs["Object"], sep.inputs[0])
        div = node(nt, "ShaderNodeMath", loc=(x + 360, 0))
        div.operation = "DIVIDE"
        link(nt, sep.outputs["Z"], div.inputs[0])
        if kind == "dome":
            div.inputs[1].default_value = d["dome"] * 0.35
        elif kind in {"disc", "floor"}:
            div.inputs[1].default_value = 1e6
        else:
            div.inputs[1].default_value = d["curve"] + d["h"] * 2.5
        fac = div.outputs[0]
    elif mode == "HORIZONTAL":
        sep = node(nt, "ShaderNodeSeparateXYZ", loc=(x + 180, 0))
        link(nt, tc.outputs["Object"], sep.inputs[0])
        div = node(nt, "ShaderNodeMath", loc=(x + 360, 0))
        div.operation = "DIVIDE"
        link(nt, sep.outputs["X"], div.inputs[0])
        div.inputs[1].default_value = d["R"] * 10
        ab = node(nt, "ShaderNodeMath", loc=(x + 540, 0))
        ab.operation = "ADD"
        ab.inputs[1].default_value = 0.5
        link(nt, div.outputs[0], ab.inputs[0])
        fac = ab.outputs[0]
    else:
        dist = node(nt, "ShaderNodeVectorMath", loc=(x + 180, 0))
        dist.operation = "DISTANCE"
        link(nt, tc.outputs["Object"], dist.inputs[0])
        if kind == "cyc":
            dist.inputs[1].default_value = (0.0, d["offset"] + d["curve"], d["h"] * 1.2)
            rad = d["R"] * 9
        elif kind == "dome":
            dist.inputs[1].default_value = (0.0, 0.0, 0.0)
            rad = d["dome"]
        else:
            dist.inputs[1].default_value = (0.0, 0.0, 0.0)
            rad = d["R"] * 12
        div = node(nt, "ShaderNodeMath", loc=(x + 360, 0))
        div.operation = "DIVIDE"
        link(nt, out_value(dist), div.inputs[0])
        div.inputs[1].default_value = rad
        fac = div.outputs[0]
    mr = node(nt, "ShaderNodeMapRange", "SR_GradMap", (x + 900, 0))
    mr.clamp = True
    link(nt, fac, mr.inputs[0])
    set_map(mr, p)
    return mr.outputs[0]


def out_value(n):
    for s in n.outputs:
        if s.name == "Value":
            return s
    return n.outputs[0]


def set_map(mr, p):
    lo = p.gradient_position - p.gradient_softness * 0.5
    hi = p.gradient_position + p.gradient_softness * 0.5
    if hi - lo < 1e-3:
        hi = lo + 1e-3
    mr.inputs[1].default_value = lo
    mr.inputs[2].default_value = hi


def aspect(scene):
    r = scene.render
    return (r.resolution_x * r.pixel_aspect_x) / max(1, r.resolution_y * r.pixel_aspect_y)


def finish_nodes(nt, bsdf, finish_id, color_socket, R, rough_value, x=-500, y=-400):
    f = by_id(FINISHES, finish_id)
    _, _, rough, metal, coat, spec, pattern = f
    put(bsdf, "Metallic", metal)
    put(bsdf, "Coat Weight", coat)
    put(bsdf, "Coat Roughness", 0.03)
    put(bsdf, "Specular IOR Level", spec)
    rv = node(nt, "ShaderNodeValue", "SR_Rough", (x - 400, y))
    rv.outputs[0].default_value = rough_value
    tc = node(nt, "ShaderNodeTexCoord", loc=(x - 900, y - 200))
    scale = node(nt, "ShaderNodeVectorMath", loc=(x - 700, y - 200))
    scale.operation = "SCALE"
    link(nt, tc.outputs["Object"], scale.inputs[0])
    put(scale, "Scale", 1.0 / max(R, 1e-4))
    co = scale.outputs[0]
    color_out = color_socket
    rough_out = rv.outputs[0]
    bump_h = None
    if pattern == "concrete":
        nz = node(nt, "ShaderNodeTexNoise", loc=(x - 500, y - 200))
        link(nt, co, nz.inputs["Vector"])
        put(nz, "Scale", 6.0)
        put(nz, "Detail", 12.0)
        put(nz, "Roughness", 0.65)
        mix = node(nt, "ShaderNodeMix", loc=(x - 200, y))
        mix.data_type = "RGBA"
        mix.blend_type = "MULTIPLY"
        mix.inputs[0].default_value = 0.35
        link(nt, color_socket, mix.inputs[6])
        link(nt, out_sock(nz, "Color"), mix.inputs[7])
        color_out = mix.outputs[2]
        bump_h = out_sock(nz, "Fac", "Factor")
    elif pattern == "terrazzo":
        vo = node(nt, "ShaderNodeTexVoronoi", loc=(x - 500, y - 200))
        link(nt, co, vo.inputs["Vector"])
        put(vo, "Scale", 9.0)
        put(vo, "Randomness", 1.0)
        ramp = node(nt, "ShaderNodeValToRGB", loc=(x - 300, y - 200))
        ramp.color_ramp.interpolation = "CONSTANT"
        el = ramp.color_ramp.elements
        el[0].position = 0.0
        el[0].color = (0.92, 0.9, 0.86, 1)
        el[1].position = 0.55
        el[1].color = (0.25, 0.24, 0.23, 1)
        e3 = el.new(0.75)
        e3.color = (0.75, 0.42, 0.3, 1)
        e4 = el.new(0.9)
        e4.color = (0.55, 0.6, 0.58, 1)
        link(nt, out_sock(vo, "Color"), ramp.inputs[0])
        vo2 = node(nt, "ShaderNodeTexVoronoi", loc=(x - 500, y - 600))
        link(nt, co, vo2.inputs["Vector"])
        put(vo2, "Scale", 9.0)
        lt = node(nt, "ShaderNodeMath", loc=(x - 300, y - 450))
        lt.operation = "LESS_THAN"
        link(nt, out_sock(vo2, "Distance"), lt.inputs[0])
        lt.inputs[1].default_value = 0.28
        mix = node(nt, "ShaderNodeMix", loc=(x - 100, y))
        mix.data_type = "RGBA"
        link(nt, lt.outputs[0], mix.inputs[0])
        link(nt, color_socket, mix.inputs[6])
        link(nt, ramp.outputs[0], mix.inputs[7])
        color_out = mix.outputs[2]
    elif pattern == "marble":
        nz = node(nt, "ShaderNodeTexNoise", loc=(x - 700, y - 400))
        link(nt, co, nz.inputs["Vector"])
        put(nz, "Scale", 0.6)
        put(nz, "Detail", 6.0)
        put(nz, "Distortion", 1.2)
        wv = node(nt, "ShaderNodeTexWave", loc=(x - 500, y - 200))
        link(nt, out_sock(nz, "Color"), wv.inputs["Vector"])
        put(wv, "Scale", 0.5)
        put(wv, "Distortion", 3.0)
        put(wv, "Detail", 4.0)
        ramp = node(nt, "ShaderNodeValToRGB", loc=(x - 300, y - 200))
        el = ramp.color_ramp.elements
        el[0].position = 0.0
        el[0].color = (0.32, 0.31, 0.3, 1)
        el[1].position = 0.07
        el[1].color = (1, 1, 1, 1)
        link(nt, out_sock(wv, "Fac", "Factor"), ramp.inputs[0])
        mix = node(nt, "ShaderNodeMix", loc=(x - 100, y))
        mix.data_type = "RGBA"
        mix.blend_type = "MULTIPLY"
        mix.inputs[0].default_value = 0.7
        link(nt, color_socket, mix.inputs[6])
        link(nt, ramp.outputs[0], mix.inputs[7])
        color_out = mix.outputs[2]
    elif pattern == "brushed":
        mp = node(nt, "ShaderNodeMapping", loc=(x - 600, y - 200))
        link(nt, co, mp.inputs["Vector"])
        mp.inputs["Scale"].default_value = (1.0, 120.0, 1.0)
        nz = node(nt, "ShaderNodeTexNoise", loc=(x - 400, y - 200))
        link(nt, mp.outputs[0], nz.inputs["Vector"])
        put(nz, "Scale", 4.0)
        put(nz, "Detail", 6.0)
        mr = node(nt, "ShaderNodeMapRange", loc=(x - 200, y - 200))
        link(nt, out_sock(nz, "Fac", "Factor"), mr.inputs[0])
        mr.inputs[3].default_value = 0.6
        link(nt, rv.outputs[0], mr.inputs[4])
        rough_out = mr.outputs[0]
        put(bsdf, "Anisotropic", 0.7)
    elif pattern == "wet":
        nz = node(nt, "ShaderNodeTexNoise", loc=(x - 500, y - 200))
        link(nt, co, nz.inputs["Vector"])
        put(nz, "Scale", 1.6)
        put(nz, "Detail", 4.0)
        mr = node(nt, "ShaderNodeMapRange", loc=(x - 250, y - 200))
        link(nt, out_sock(nz, "Fac", "Factor"), mr.inputs[0])
        mr.inputs[1].default_value = 0.45
        mr.inputs[2].default_value = 0.6
        link(nt, rv.outputs[0], mr.inputs[3])
        mr.inputs[4].default_value = 0.55
        rough_out = mr.outputs[0]
        dk = node(nt, "ShaderNodeMix", loc=(x - 100, y))
        dk.data_type = "RGBA"
        dk.blend_type = "MULTIPLY"
        dk.inputs[0].default_value = 0.5
        link(nt, color_socket, dk.inputs[6])
        dk.inputs[7].default_value = (0.55, 0.55, 0.58, 1)
        color_out = dk.outputs[2]
    elif pattern == "velvet":
        put(bsdf, "Sheen Weight", 1.0)
        put(bsdf, "Sheen Roughness", 0.3)
    link(nt, color_out, bsdf.inputs["Base Color"])
    link(nt, rough_out, bsdf.inputs["Roughness"])
    if bump_h is not None:
        bump = node(nt, "ShaderNodeBump", loc=(x, y - 300))
        put(bump, "Strength", 0.08)
        put(bump, "Distance", 0.02 * R)
        link(nt, bump_h, bump.inputs["Height"])
        link(nt, bump.outputs[0], bsdf.inputs["Normal"])
    return color_out


def out_sock(n, *keys):
    return core.out_sock(n, *keys)


def surface_material(scene, name, kind, d, finish, with_gradient=True, color=None):
    p = P(scene)
    mat, nt = core.material(name)
    out = node(nt, "ShaderNodeOutputMaterial", loc=(500, 0))
    bsdf = node(nt, "ShaderNodeBsdfPrincipled", "SR_BSDF", (200, 0))
    link(nt, bsdf.outputs[0], out.inputs["Surface"])
    ca = node(nt, "ShaderNodeRGB", "SR_ColA", (-700, 250))
    cb = node(nt, "ShaderNodeRGB", "SR_ColB", (-700, 400))
    if color is not None:
        cb.outputs[0].default_value = tuple(color) + (1.0,)
        ca.outputs[0].default_value = tuple(color) + (1.0,)
        col = cb.outputs[0]
    else:
        ca.outputs[0].default_value = tuple(p.color_a) + (1.0,)
        cb.outputs[0].default_value = tuple(p.color_b) + (1.0,)
        fac = gradient_factor(nt, scene, kind, d) if with_gradient else None
        if fac is None:
            col = cb.outputs[0]
        else:
            mix = node(nt, "ShaderNodeMix", "SR_GradMix", (-300, 300))
            mix.data_type = "RGBA"
            link(nt, fac, mix.inputs[0])
            link(nt, cb.outputs[0], mix.inputs[6])
            link(nt, ca.outputs[0], mix.inputs[7])
            col = mix.outputs[2]
    col_final = finish_nodes(nt, bsdf, finish, col, d["R"], p.floor_roughness if color is None else by_id(FINISHES, finish)[2])
    if color is None:
        link(nt, col_final, bsdf.inputs["Emission Color"])
        em = node(nt, "ShaderNodeValue", "SR_Glow", (-100, -150))
        em.outputs[0].default_value = p.backdrop_glow
        link(nt, em.outputs[0], bsdf.inputs["Emission Strength"])
    return mat


def dome_material(scene, d):
    p = P(scene)
    mat, nt = core.material("SR Dome")
    out = node(nt, "ShaderNodeOutputMaterial", loc=(500, 0))
    bsdf = node(nt, "ShaderNodeBsdfPrincipled", "SR_BSDF", (200, 0))
    link(nt, bsdf.outputs[0], out.inputs["Surface"])
    put(bsdf, "Roughness", 0.9)
    put(bsdf, "Specular IOR Level", 0.1)
    ca = node(nt, "ShaderNodeRGB", "SR_ColA", (-700, 250))
    cb = node(nt, "ShaderNodeRGB", "SR_ColB", (-700, 400))
    ca.outputs[0].default_value = tuple(p.color_a) + (1.0,)
    cb.outputs[0].default_value = tuple(p.color_b) + (1.0,)
    fac = gradient_factor(nt, scene, "dome", d)
    if fac is None:
        col = cb.outputs[0]
    else:
        mix = node(nt, "ShaderNodeMix", "SR_GradMix", (-300, 300))
        mix.data_type = "RGBA"
        link(nt, fac, mix.inputs[0])
        link(nt, cb.outputs[0], mix.inputs[6])
        link(nt, ca.outputs[0], mix.inputs[7])
        col = mix.outputs[2]
    link(nt, col, bsdf.inputs["Base Color"])
    link(nt, col, bsdf.inputs["Emission Color"])
    em = node(nt, "ShaderNodeValue", "SR_Glow", (-100, -150))
    em.outputs[0].default_value = 0.35 + p.backdrop_glow
    link(nt, em.outputs[0], bsdf.inputs["Emission Strength"])
    return mat


def build_studio(scene):
    p = P(scene)
    core.remove_roles(scene, *STAGE_ROLES)
    d = stage_dims(scene)
    stage = core.new_empty(scene, "SR Stage", "stage", "stage", "SINGLE_ARROW", d["R"])
    kind = p.backdrop_type
    if kind == "CYC":
        me = bpy.data.meshes.new("SR Cyclorama")
        cyc_mesh(me, d)
        ob = core.new_object(scene, "SR Cyclorama", me, "backdrop", "stage", stage)
        core.assign_material(ob, surface_material(scene, "SR Backdrop", "cyc", d, p.floor_finish))
    elif kind == "DOME":
        me = bpy.data.meshes.new("SR 360 Dome")
        dome_mesh(me, d["dome"])
        ob = core.new_object(scene, "SR 360 Dome", me, "backdrop", "stage", stage)
        core.assign_material(ob, dome_material(scene, d))
        me2 = bpy.data.meshes.new("SR 360 Floor")
        disc_mesh(me2, d["dome"] * 1.001, 0.0)
        fl = core.new_object(scene, "SR 360 Floor", me2, "floor", "stage", stage)
        core.assign_material(fl, surface_material(scene, "SR Floor", "disc", d, p.floor_finish))
    elif kind == "IMAGE":
        if p.image_floor != "NONE":
            me = bpy.data.meshes.new("SR Shadow Floor")
            disc_mesh(me, d["dome"] * 0.6, 0.0, 48, 3)
            fl = core.new_object(scene, "SR Shadow Floor", me, "catcher", "stage", stage)
            mat, nt = core.material("SR Shadow Floor")
            out = node(nt, "ShaderNodeOutputMaterial", loc=(300, 0))
            bs = node(nt, "ShaderNodeBsdfPrincipled", loc=(0, 0))
            put(bs, "Base Color", (0.5, 0.5, 0.5, 1))
            put(bs, "Roughness", 0.6)
            link(nt, bs.outputs[0], out.inputs["Surface"])
            core.assign_material(fl, mat)
            fl.is_shadow_catcher = True
    build_podium(scene, stage, d)
    for o in core.tagged(scene, *STAGE_ROLES):
        if o.type == "MESH":
            o.hide_select = p.lock_studio
    update_stage_transform(scene)
    build_world(scene)
    sync_engine_visibility(scene)
    from . import lighting
    lighting.refresh_flags(scene)
    return stage


def build_podium(scene, stage, d):
    p = P(scene)
    core.remove_roles(scene, "podium")
    if p.podium_type == "NONE":
        return None
    info = core.product_info(scene)
    R = info["R"]
    w, dd = info["dims"].x, info["dims"].y
    pad = 1.0 + p.podium_padding
    hgt = p.podium_height * R
    me = bpy.data.meshes.new("SR Podium")
    if p.podium_type in {"BOX", "ROUNDED"}:
        podium_mesh(me, p.podium_type, w * 0.5 * pad, dd * 0.5 * pad, hgt)
    else:
        rr = 0.5 * max(w, dd) * pad
        podium_mesh(me, p.podium_type, rr, rr, hgt)
    ob = core.new_object(scene, "SR Podium", me, "podium", "stage")
    ob.location = info["base"]
    bevel = 0.25 if p.podium_type == "ROUNDED" else 0.025
    add_bevel(ob, min(hgt, max(w, dd)) * bevel, 6 if p.podium_type == "ROUNDED" else 3)
    mat = surface_material(scene, "SR Podium", "podium", d, p.podium_finish, False, p.podium_color)
    core.assign_material(ob, mat)
    ob.hide_select = p.lock_studio
    return ob


def update_stage_transform(scene):
    p = P(scene)
    stage = core.first(scene, "stage")
    if stage is None:
        return
    info = core.product_info(scene)
    stage.location = (info["base"].x, info["base"].y, core.floor_z(scene))
    az = core.camera_az(scene) if (p.backdrop_type == "CYC" and p.cyc_face_camera) else 0.0
    stage.rotation_euler = (0.0, 0.0, math.radians(az) + p.backdrop_rotation)
    pod = core.first(scene, "podium")
    if pod is not None:
        pod.location = info["base"]


def update_studio_values(scene):
    p = P(scene)
    names = ["SR Backdrop", "SR Floor", "SR Dome"]
    for nm in names:
        mat = bpy.data.materials.get(nm)
        if mat is None or mat.node_tree is None:
            continue
        nodes = mat.node_tree.nodes
        if "SR_ColA" in nodes:
            nodes["SR_ColA"].outputs[0].default_value = tuple(p.color_a) + (1.0,)
        if "SR_ColB" in nodes:
            nodes["SR_ColB"].outputs[0].default_value = tuple(p.color_b) + (1.0,)
        if "SR_GradMap" in nodes:
            set_map(nodes["SR_GradMap"], p)
        if "SR_Glow" in nodes:
            nodes["SR_Glow"].outputs[0].default_value = p.backdrop_glow + (0.35 if nm == "SR Dome" else 0.0)
        if "SR_Rough" in nodes:
            nodes["SR_Rough"].outputs[0].default_value = p.floor_roughness
        if "SR_Aspect" in nodes:
            nodes["SR_Aspect"].inputs[1].default_value = (aspect(scene) * 1.4, 1.4, 0.0)
    pm = bpy.data.materials.get("SR Podium")
    if pm is not None and pm.node_tree is not None:
        for key in ("SR_ColA", "SR_ColB"):
            if key in pm.node_tree.nodes:
                pm.node_tree.nodes[key].outputs[0].default_value = tuple(p.podium_color) + (1.0,)


def load_image(path):
    if not path:
        return None
    full = bpy.path.abspath(path)
    if not os.path.isfile(full):
        return None
    try:
        return bpy.data.images.load(full, check_existing=True)
    except RuntimeError:
        return None


def image_fit(scene, img, mode):
    if img is None or img.size[1] == 0:
        return (1.0, 1.0)
    ia = img.size[0] / img.size[1]
    fa = aspect(scene)
    if mode == "STRETCH":
        return (1.0, 1.0)
    if mode == "FILL":
        return (fa / ia, 1.0) if ia > fa else (1.0, ia / fa)
    return (1.0, ia / fa) if ia > fa else (fa / ia, 1.0)


def world(scene):
    w = bpy.data.worlds.get("SR World")
    if w is None:
        w = bpy.data.worlds.new("SR World")
    if scene.world is not w:
        if scene.world is not None and not scene.world.name.startswith("SR World"):
            P(scene).prev_world = scene.world.name
        scene.world = w
    if w.node_tree is None:
        w.use_nodes = True
    return w


def build_world(scene):
    p = P(scene)
    w = world(scene)
    nt = w.node_tree
    nt.nodes.clear()
    out = node(nt, "ShaderNodeOutputWorld", loc=(600, 0))
    light_bg = node(nt, "ShaderNodeBackground", "SR_WLight", (200, 100))
    light_bg.inputs["Strength"].default_value = p.world_strength
    hdri = load_image(p.hdri_path)
    if hdri is not None:
        tc = node(nt, "ShaderNodeTexCoord", loc=(-700, 100))
        mp = node(nt, "ShaderNodeMapping", "SR_HdriMap", (-500, 100))
        mp.inputs["Rotation"].default_value = (0.0, 0.0, math.radians(p.hdri_rotation))
        link(nt, tc.outputs["Generated"], mp.inputs["Vector"])
        env = node(nt, "ShaderNodeTexEnvironment", loc=(-250, 100))
        env.image = hdri
        link(nt, mp.outputs[0], env.inputs["Vector"])
        tint = node(nt, "ShaderNodeMix", loc=(0, 150))
        tint.data_type = "RGBA"
        tint.blend_type = "MULTIPLY"
        tint.inputs[0].default_value = 1.0
        link(nt, env.outputs["Color"], tint.inputs[6])
        wc = node(nt, "ShaderNodeRGB", "SR_WCol", (-250, -100))
        wc.outputs[0].default_value = (1, 1, 1, 1)
        link(nt, wc.outputs[0], tint.inputs[7])
        link(nt, tint.outputs[2], light_bg.inputs["Color"])
    else:
        wc = node(nt, "ShaderNodeRGB", "SR_WCol", (-100, 100))
        wc.outputs[0].default_value = tuple(p.world_color) + (1.0,)
        link(nt, wc.outputs[0], light_bg.inputs["Color"])
    img = load_image(p.image_path) if p.backdrop_type == "IMAGE" else None
    if img is None and not (hdri is not None and p.hdri_hide):
        link(nt, light_bg.outputs[0], out.inputs["Surface"])
        return w
    cam_bg = node(nt, "ShaderNodeBackground", "SR_WCam", (200, -100))
    if img is not None:
        tc = node(nt, "ShaderNodeTexCoord", loc=(-700, -200))
        mp = node(nt, "ShaderNodeMapping", "SR_ImgMap", (-500, -200))
        sx, sy = image_fit(scene, img, p.image_fit)
        mp.inputs["Scale"].default_value = (sx, sy, 1.0)
        mp.inputs["Location"].default_value = (0.5 - 0.5 * sx, 0.5 - 0.5 * sy, 0.0)
        link(nt, tc.outputs["Window"], mp.inputs["Vector"])
        tex = node(nt, "ShaderNodeTexImage", loc=(-250, -200))
        tex.image = img
        tex.extension = "CLIP"
        link(nt, mp.outputs[0], tex.inputs["Vector"])
        link(nt, tex.outputs["Color"], cam_bg.inputs["Color"])
        cam_bg.inputs["Strength"].default_value = p.image_strength
    else:
        cam_bg.inputs["Color"].default_value = tuple(p.world_color) + (1.0,)
        cam_bg.inputs["Strength"].default_value = 1.0
    lp = node(nt, "ShaderNodeLightPath", loc=(200, 300))
    mix = node(nt, "ShaderNodeMixShader", loc=(420, 0))
    link(nt, lp.outputs["Is Camera Ray"], mix.inputs[0])
    if img is not None and p.image_light:
        link(nt, cam_bg.outputs[0], mix.inputs[1])
    else:
        link(nt, light_bg.outputs[0], mix.inputs[1])
    link(nt, cam_bg.outputs[0], mix.inputs[2])
    link(nt, mix.outputs[0], out.inputs["Surface"])
    return w


def update_world_values(scene):
    p = P(scene)
    w = scene.world
    if w is None or w.node_tree is None or not w.name.startswith("SR World"):
        return
    nodes = w.node_tree.nodes
    if "SR_WLight" in nodes:
        nodes["SR_WLight"].inputs["Strength"].default_value = p.world_strength
    if "SR_WCol" in nodes and not p.hdri_path:
        nodes["SR_WCol"].outputs[0].default_value = tuple(p.world_color) + (1.0,)
    if "SR_HdriMap" in nodes:
        nodes["SR_HdriMap"].inputs["Rotation"].default_value = (0.0, 0.0, math.radians(p.hdri_rotation))
    if "SR_WCam" in nodes and "SR_ImgMap" in nodes:
        nodes["SR_WCam"].inputs["Strength"].default_value = p.image_strength
        img = load_image(p.image_path)
        sx, sy = image_fit(scene, img, p.image_fit)
        nodes["SR_ImgMap"].inputs["Scale"].default_value = (sx, sy, 1.0)
        nodes["SR_ImgMap"].inputs["Location"].default_value = (0.5 - 0.5 * sx, 0.5 - 0.5 * sy, 0.0)


def sync_engine_visibility(scene):
    for o in core.tagged(scene, "catcher"):
        o.hide_render = core.is_eevee(scene)
