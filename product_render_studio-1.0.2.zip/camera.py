import bpy
import math
from mathutils import Vector, Euler
from . import core
from .core import P
from .presets import SHOTS, by_id

CAM_ROLES = ("cam_rig", "camera", "focus")


def parts(scene):
    return core.first(scene, "cam_rig"), core.first(scene, "camera"), core.first(scene, "focus")


def ensure_rig(scene):
    rig, cam, focus = parts(scene)
    if rig is not None and cam is not None and focus is not None:
        return rig, cam, focus
    core.remove_roles(scene, *CAM_ROLES)
    info = core.product_info(scene)
    rig = core.new_empty(scene, "SR Camera Rig", "cam_rig", "camera", "SPHERE", info["R"] * 0.15)
    data = bpy.data.cameras.new("SR Camera")
    cam = core.new_object(scene, "SR Camera", data, "camera", "camera", rig)
    focus = core.new_empty(scene, "SR Focus", "focus", "camera", "CONE", info["R"] * 0.1, rig)
    data.sensor_fit = "AUTO"
    data.sensor_width = 36.0
    data.show_passepartout = True
    data.passepartout_alpha = 0.85
    return rig, cam, focus


def corners(scene):
    info = core.product_info(scene)
    b = info["base"]
    w, d, h = info["dims"]
    out = []
    for x in (-w / 2, w / 2):
        for y in (-d / 2, d / 2):
            for z in (0.0, h):
                out.append(b + Vector((x, y, z)))
    p = P(scene)
    if p.podium_type != "NONE":
        pad = 1.0 + p.podium_padding
        z = -p.podium_height * info["R"] * 0.5
        for x in (-w / 2 * pad, w / 2 * pad):
            for y in (-d / 2 * pad, d / 2 * pad):
                out.append(b + Vector((x, y, z)))
    return out


def basis(az, el):
    m = Euler((-math.radians(el), 0.0, math.radians(az)), "XYZ").to_matrix()
    return m @ Vector((1, 0, 0)), m @ Vector((0, 0, 1)), m @ Vector((0, -1, 0))


def half_angles(lens, aspect):
    half = 18.0 / max(lens, 1.0)
    if aspect >= 1.0:
        return half, half / aspect
    return half * aspect, half


def fit_distance(pts, aim, az, el, lens, aspect, pad, roll):
    right, up, back = basis(az, el)
    th, tv = half_angles(lens, aspect)
    k = 1.0 / (1.0 + max(pad, -0.9))
    cr, sr = math.cos(math.radians(roll)), math.sin(math.radians(roll))
    dist = 0.0
    for c in pts:
        rel = c - aim
        x, y, z = rel.dot(right), rel.dot(up), rel.dot(back)
        xr = x * cr + y * sr
        yr = -x * sr + y * cr
        dist = max(dist, z + abs(xr) / (th * k), z + abs(yr) / (tv * k))
    return dist


def aspect(scene):
    r = scene.render
    return (r.resolution_x * r.pixel_aspect_x) / max(1, r.resolution_y * r.pixel_aspect_y)


def shot_angles(scene):
    p = P(scene)
    row = by_id(SHOTS, p.shot)
    return row[2] + p.cam_azimuth, row[3] + p.cam_elevation, row[8]


def apply_camera(scene, rebuild_anim=True):
    p = P(scene)
    info = core.product_info(scene)
    R, h = info["R"], info["h"]
    az, el, macro = shot_angles(scene)
    rig, cam, focus = ensure_rig(scene)
    aim = info["center"] + Vector((0.0, 0.0, (p.aim_height - 0.5) * h))
    pts = corners(scene)
    if macro:
        _, _, back = basis(az, 0.0)
        front = max((c - info["center"]).dot(back) for c in pts)
        aim = aim + back * front * 0.8
    dist = fit_distance(pts, aim, az, el, p.focal_length, aspect(scene), p.frame_padding, p.cam_roll)
    if macro:
        dist *= p.macro_zoom
    dist = max(dist, R * 0.05)
    floor = core.floor_z(scene) + 0.04 * R
    el_min = math.degrees(math.asin(max(-1.0, min(1.0, (floor - aim.z) / dist))))
    if el < el_min:
        el = el_min
        if not macro:
            dist = fit_distance(pts, aim, az, el, p.focal_length, aspect(scene), p.frame_padding, p.cam_roll)
    rig.location = aim
    rig.rotation_euler = (-math.radians(el), 0.0, math.radians(az))
    cam.location = (0.0, -dist, 0.0)
    cam.rotation_euler = (math.radians(90.0 + p.cam_tilt), math.radians(p.cam_roll), 0.0)
    data = cam.data
    data.lens = p.focal_length
    data.shift_x = p.frame_offset_x
    data.shift_y = p.frame_offset_y
    data.clip_start = max(0.0005, dist * 0.01)
    data.clip_end = max(dist * 50.0, R * 400.0)
    data.dof.use_dof = p.use_dof
    data.dof.aperture_fstop = p.fstop
    data.dof.focus_object = focus
    data.show_composition_thirds = p.show_thirds
    focus.location = (0.0, p.focus_offset * R, 0.0)
    rig["sr_az"] = az
    rig["sr_el"] = el
    rig["sr_dist"] = dist
    rig["sr_lens"] = p.focal_length
    rig["sr_el_min"] = el_min
    rig["sr_aim"] = list(aim)
    scene.camera = cam
    from . import studio, lighting, prepare, animation
    prepare.update_alignment(scene)
    studio.update_stage_transform(scene)
    lighting.update_lights(scene)
    if rebuild_anim and p.camera_anim != "STATIC":
        animation.apply_camera_anim(scene)
    return cam


def look_through(context):
    scene = context.scene
    rig, cam, focus = parts(scene)
    if cam is None:
        return False
    scene.camera = cam
    screen = context.screen
    if screen is None:
        return True
    for area in screen.areas:
        if area.type == "VIEW_3D":
            for space in area.spaces:
                if space.type == "VIEW_3D":
                    space.region_3d.view_perspective = "CAMERA"
            area.tag_redraw()
    return True


def set_shading(context, kind):
    screen = context.screen
    if screen is None:
        return
    for area in screen.areas:
        if area.type == "VIEW_3D":
            for space in area.spaces:
                if space.type == "VIEW_3D":
                    space.shading.type = kind
