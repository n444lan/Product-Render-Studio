import bpy
import math
from mathutils import Vector
from . import core, studio
from .core import P, node, link
from .presets import LIGHT_PRESETS, by_id

LIGHT_ROLES = ("light", "halo", "neon", "light_rig")
IRRADIANCE = 3.2
EMIT_HALO = 4.0
EMIT_NEON = 3.0


def rig_rotation(scene):
    p = P(scene)
    base = core.camera_az(scene) if p.light_follow_camera else 0.0
    return math.radians(base) + p.light_rotation


def light_energy(kind, power, d, area):
    if kind == "U":
        return power * IRRADIANCE
    if kind in {"P", "S", "B"}:
        return power * IRRADIANCE * 4 * math.pi * d * d
    return power * IRRADIANCE * (math.pi * d * d + area)


def spec_position(scene, spec, R, dist_factor):
    label, kind, az, el, dist, sx, sy, power, color, spread = spec
    pos = core.sph(az, el) * dist * R * dist_factor
    info = core.product_info(scene)
    min_z = core.floor_z(scene) + 0.08 * R - info["center"].z
    if pos.z < min_z:
        pos.z = min_z
    return pos


def wall_target(scene, R):
    p = P(scene)
    d = studio.stage_dims(scene)
    if p.backdrop_type == "CYC":
        y = d["offset"] + d["curve"]
    elif p.backdrop_type == "DOME":
        y = d["dome"] * 0.4
    else:
        y = 8 * R
    return Vector((0.0, y, R * 0.6))


def emissive_material(name, color, strength):
    mat, nt = core.material(name)
    out = node(nt, "ShaderNodeOutputMaterial", loc=(300, 0))
    em = node(nt, "ShaderNodeEmission", "SR_Emit", (0, 0))
    em.inputs["Color"].default_value = tuple(color) + (1.0,)
    em.inputs["Strength"].default_value = strength
    link(nt, em.outputs[0], out.inputs["Surface"])
    return mat


def torus_mesh(me, major, minor, segs=128, sides=16):
    verts = []
    for i in range(segs):
        u = 2 * math.pi * i / segs
        cu, su = math.cos(u), math.sin(u)
        for j in range(sides):
            v = 2 * math.pi * j / sides
            r = major + minor * math.cos(v)
            verts.append((r * cu, r * su, minor * math.sin(v)))
    faces = []
    for i in range(segs):
        for j in range(sides):
            a = i * sides + j
            b = ((i + 1) % segs) * sides + j
            c = ((i + 1) % segs) * sides + (j + 1) % sides
            d = i * sides + (j + 1) % sides
            faces.append((a, b, c, d))
    return core.set_mesh(me, verts, faces, smooth=True)


def tube_mesh(me, length, radius, sides=24):
    verts = []
    for y in (-length / 2, length / 2):
        for j in range(sides):
            v = 2 * math.pi * j / sides
            verts.append((radius * math.cos(v), y, radius * math.sin(v)))
    faces = [tuple(range(sides - 1, -1, -1)), tuple(range(sides, 2 * sides))]
    for j in range(sides):
        k = (j + 1) % sides
        faces.append((j, k, sides + k, sides + j))
    return core.set_mesh(me, verts, faces, smooth=True)


def build_lights(scene):
    p = P(scene)
    core.remove_roles(scene, *LIGHT_ROLES)
    info = core.product_info(scene)
    R = info["R"]
    rig = core.new_empty(scene, "SR Light Rig", "light_rig", "lights", "SPHERE", R * 0.3)
    rig.location = info["center"]
    rig.rotation_euler = (0.0, 0.0, rig_rotation(scene))
    preset = by_id(LIGHT_PRESETS, p.light_preset)
    for i, spec in enumerate(preset[5]):
        make_light(scene, rig, spec, i, R)
    update_lights(scene)
    refresh_flags(scene)
    studio.build_world(scene)
    return rig


def make_light(scene, rig, spec, index, R):
    label, kind, az, el, dist, sx, sy, power, color, spread = spec
    name = "SR " + label
    if kind == "H":
        me = bpy.data.meshes.new(name)
        torus_mesh(me, sx * R, max(sy * R, 1e-4))
        ob = core.new_object(scene, name, me, "halo", "lights", rig)
        core.assign_material(ob, emissive_material("SR Halo %d" % index, core.color_of(color), power * EMIT_HALO))
        core.set_ray_visibility(ob, camera=True, diffuse=True, glossy=True, shadow=False, transmission=True)
    elif kind == "N":
        me = bpy.data.meshes.new(name)
        tube_mesh(me, sx * R, max(sy * R, 1e-4))
        ob = core.new_object(scene, name, me, "neon", "lights", rig)
        core.assign_material(ob, emissive_material("SR Neon %d" % index, core.color_of(color), power * EMIT_NEON))
        core.set_ray_visibility(ob, camera=True, diffuse=True, glossy=True, shadow=False, transmission=True)
    else:
        ltype = {"A": "AREA", "D": "AREA", "P": "POINT", "S": "SPOT", "B": "SPOT", "U": "SUN"}[kind]
        data = bpy.data.lights.new(name, ltype)
        ob = core.new_object(scene, name, data, "light", "lights", rig)
        if hasattr(data, "use_temperature"):
            data.use_temperature = False
        core.set_ray_visibility(ob, camera=False, diffuse=True, glossy=True, shadow=True, transmission=True)
        if kind in {"A", "D"}:
            if kind == "D":
                data.shape = "DISK"
            elif abs(sx - sy) < 1e-6:
                data.shape = "SQUARE"
            else:
                data.shape = "RECTANGLE"
            if spread:
                data.spread = math.radians(spread)
        elif kind in {"S", "B"}:
            data.spot_size = math.radians(sx)
            data.spot_blend = sy
        elif kind == "U":
            data.angle = math.radians(max(sx, 0.05))
    ob["sr_kind"] = kind
    ob["sr_az"] = float(az)
    ob["sr_el"] = float(el)
    ob["sr_dist"] = float(dist)
    ob["sr_sx"] = float(sx)
    ob["sr_sy"] = float(sy)
    ob["sr_power"] = float(power)
    ob["sr_color"] = list(core.color_of(color))
    ob["sr_index"] = index
    return ob


def spec_of(ob):
    return (ob.name, ob["sr_kind"], ob["sr_az"], ob["sr_el"], ob["sr_dist"], ob["sr_sx"], ob["sr_sy"],
            ob["sr_power"], 6500, 0.0)


def update_lights(scene):
    p = P(scene)
    rig = core.first(scene, "light_rig")
    if rig is None:
        return
    info = core.product_info(scene)
    R = info["R"]
    rig.location = info["center"]
    rig.rotation_euler = (0.0, 0.0, rig_rotation(scene))
    tint = core.temperature_tint(p.light_temperature)
    for ob in core.tagged(scene, "light", "halo", "neon"):
        if "sr_kind" not in ob:
            continue
        kind = ob["sr_kind"]
        spec = spec_of(ob)
        pos = spec_position(scene, spec, R, p.light_distance)
        ob.location = pos
        color = Vector([ob["sr_color"][i] * tint[i] for i in range(3)])
        if kind == "B":
            target = wall_target(scene, R)
            ob.rotation_euler = core.look_matrix(target - pos)
            dist = (target - pos).length
        elif kind in {"H", "N"}:
            ob.rotation_euler = core.look_matrix(-pos, "Z", "Y")
            ob.scale = (p.light_size, p.light_size, p.light_size)
            mat = ob.data.materials[0] if ob.data.materials else None
            if mat is not None and "SR_Emit" in mat.node_tree.nodes:
                em = mat.node_tree.nodes["SR_Emit"]
                em.inputs["Color"].default_value = tuple(color) + (1.0,)
                em.inputs["Strength"].default_value = ob["sr_power"] * (EMIT_HALO if kind == "H" else EMIT_NEON) * p.light_intensity
            continue
        else:
            ob.rotation_euler = core.look_matrix(-pos)
            dist = pos.length
        data = ob.data
        data.color = color
        sx = ob["sr_sx"] * R * p.light_size
        sy = ob["sr_sy"] * R * p.light_size
        area = 0.0
        if kind in {"A", "D"}:
            data.size = sx
            if data.shape in {"RECTANGLE", "ELLIPSE"}:
                data.size_y = sy
                area = sx * sy
            else:
                area = sx * sx
        elif kind == "P":
            data.shadow_soft_size = sx
        elif kind in {"S", "B"}:
            data.shadow_soft_size = R * 0.05 * p.light_size
        focus = 1.0
        if kind in {"A", "D"} and data.spread < math.pi - 1e-3:
            focus = 1.0 - math.cos(data.spread * 0.5)
        data.energy = light_energy(kind, ob["sr_power"], dist, area) * p.light_intensity * focus


FLAG_COLL = "SR Flagged Surfaces"


def refresh_flags(scene):
    p = P(scene)
    coll = bpy.data.collections.get(FLAG_COLL)
    if coll is None:
        coll = bpy.data.collections.new(FLAG_COLL)
    for o in list(coll.objects):
        coll.objects.unlink(o)
    for o in core.tagged(scene, "backdrop", "floor"):
        coll.objects.link(o)
    for co in coll.collection_objects:
        co.light_linking.link_state = "EXCLUDE"
    for ob in core.tagged(scene, "light"):
        if "sr_kind" not in ob or not hasattr(ob, "light_linking"):
            continue
        behind = abs(((ob["sr_az"] + 180.0) % 360.0) - 180.0) >= 100.0
        flag = p.flag_backlights and behind and ob["sr_kind"] in {"A", "D", "P", "S"}
        ob.light_linking.receiver_collection = coll if flag and len(coll.objects) else None


def select_lights(context):
    for o in context.view_layer.objects:
        o.select_set(False)
    lights = core.tagged(context.scene, "light", "halo", "neon")
    for o in lights:
        if o.name in context.view_layer.objects:
            o.select_set(True)
    if lights:
        context.view_layer.objects.active = lights[0]
    return len(lights)
