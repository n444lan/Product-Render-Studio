import math
from mathutils import Vector
from . import core, prepare, camera
from .core import P
from .presets import PRODUCT_ANIMS, CAMERA_ANIMS, by_id


def window(scene, loop):
    p = P(scene)
    f0 = scene.frame_start + p.hold_start
    f1 = scene.frame_end - p.hold_end
    if loop and p.seamless_loop:
        f1 += 1
    if f1 <= f0:
        f1 = f0 + 1
    return f0, f1


def points(keys, ease, f0, f1, base, unit, mul):
    out = []
    for k in keys:
        t, v = k[0], k[1]
        e = k[2] if len(k) > 2 else ease
        out.append((f0 + t * (f1 - f0), base + v * unit * mul, e))
    return out


def reset_product(scene):
    root, motion, spin, align = prepare.parts(scene)
    if motion is None:
        return None, None
    core.clear_anim(motion)
    core.clear_anim(spin)
    motion.location = (0.0, 0.0, 0.0)
    motion.rotation_euler = (0.0, 0.0, 0.0)
    motion.scale = (1.0, 1.0, 1.0)
    spin.rotation_euler = (0.0, 0.0, 0.0)
    spin.scale = (1.0, 1.0, 1.0)
    prepare.update_alignment(scene)
    return motion, spin


def apply_product_anim(scene):
    p = P(scene)
    motion, spin = reset_product(scene)
    if motion is None:
        return False
    row = by_id(PRODUCT_ANIMS, p.product_anim)
    loop, chans = row[3], row[4]
    info = core.product_info(scene)
    R, h = info["R"], info["h"]
    deg = math.radians(1.0)
    table = {
        "x": (motion, "location", (0,), R, 0.0),
        "y": (motion, "location", (1,), R, 0.0),
        "z": (motion, "location", (2,), R, 0.0),
        "zh": (motion, "location", (2,), h, 0.0),
        "brx": (motion, "rotation_euler", (0,), deg, 0.0),
        "bry": (motion, "rotation_euler", (1,), deg, 0.0),
        "brz": (motion, "rotation_euler", (2,), deg, 0.0),
        "bs": (motion, "scale", (0, 1, 2), 1.0, 1.0),
        "bsx": (motion, "scale", (0,), 1.0, 1.0),
        "bsy": (motion, "scale", (1,), 1.0, 1.0),
        "bsz": (motion, "scale", (2,), 1.0, 1.0),
        "rx": (spin, "rotation_euler", (0,), deg, 0.0),
        "ry": (spin, "rotation_euler", (1,), deg, 0.0),
        "rz": (spin, "rotation_euler", (2,), deg, 0.0),
        "s": (spin, "scale", (0, 1, 2), 1.0, 1.0),
        "sx": (spin, "scale", (0,), 1.0, 1.0),
        "sy": (spin, "scale", (1,), 1.0, 1.0),
        "sz": (spin, "scale", (2,), 1.0, 1.0),
    }
    f0, f1 = window(scene, loop)
    built = {}
    for name, keys, ease, fixed in chans:
        target, path, idxs, unit, base = table[name]
        mul = 1.0 if fixed else p.anim_strength
        built[name] = points(keys, ease, f0, f1, base, unit, mul)
    tilt = "brx" in built or "bry" in built
    zkey = "zh" if "zh" in built else "z"
    for name, pts in built.items():
        if tilt and name == zkey:
            continue
        target, path, idxs, unit, base = table[name]
        for i in idxs:
            core.write_keys(target, path, i, pts)
    if tilt:
        curves = {n: core.fcurve(motion, "rotation_euler", i) for n, i in (("brx", 0), ("bry", 1)) if n in built}
        core.write_keys(motion, "location", 2, tilt_lift(built, zkey, info, core.camera_az(scene), curves))
    core.refresh(scene)
    return True


def sample(pts, f):
    if not pts:
        return 0.0
    if f <= pts[0][0]:
        return pts[0][1]
    for (fa, va, _), (fb, vb, _) in zip(pts, pts[1:]):
        if fa <= f <= fb:
            u = 0.0 if fb == fa else (f - fa) / (fb - fa)
            return va + (vb - va) * u
    return pts[-1][1]


def tilt_lift(built, zkey, info, az, curves):
    w, d = info["dims"].x, info["dims"].y
    a = math.radians(az)
    hx = abs(w / 2 * math.cos(a)) + abs(d / 2 * math.sin(a))
    hy = abs(w / 2 * math.sin(a)) + abs(d / 2 * math.cos(a))
    rx = built.get("brx", [])
    ry = built.get("bry", [])
    zp = built.get(zkey, [])
    eases = {}
    for pts in (ry, rx, zp):
        for f, v, e in pts:
            eases[round(f, 4)] = e
    frames = sorted(eases)
    if not zp and len(frames) > 1:
        dense = []
        for fa, fb in zip(frames, frames[1:]):
            n = max(1, int((fb - fa) / 2))
            dense += [fa + (fb - fa) * i / n for i in range(n)]
        dense.append(frames[-1])
        for f in dense:
            eases.setdefault(round(f, 4), "smooth")
        frames = sorted(set(round(f, 4) for f in dense))
    out = []
    for f in frames:
        ax = curves["brx"].evaluate(f) if "brx" in curves else 0.0
        ay = curves["bry"].evaluate(f) if "bry" in curves else 0.0
        lift = hy * abs(math.sin(ax)) + hx * abs(math.sin(ay))
        out.append((f, sample(zp, f) + lift, eases[f]))
    return out


def reset_camera(scene):
    rig, cam, focus = camera.parts(scene)
    if rig is None:
        return None, None, None
    core.clear_anim(rig)
    core.clear_anim(cam)
    core.clear_anim(cam.data)
    core.clear_anim(focus)
    camera.apply_camera(scene, rebuild_anim=False)
    return rig, cam, focus


def apply_camera_anim(scene):
    p = P(scene)
    rig, cam, focus = reset_camera(scene)
    if rig is None:
        return False
    row = by_id(CAMERA_ANIMS, p.camera_anim)
    loop, chans = row[3], row[4]
    if not chans:
        core.refresh(scene)
        return True
    info = core.product_info(scene)
    R = info["R"]
    az = float(rig["sr_az"])
    el = float(rig["sr_el"])
    dist = float(rig["sr_dist"])
    lens = float(rig["sr_lens"])
    el_min = float(rig["sr_el_min"])
    aim = Vector(rig["sr_aim"])
    right = Vector((math.cos(math.radians(az)), math.sin(math.radians(az)), 0.0))
    f0, f1 = window(scene, loop)
    for name, keys, ease, fixed in chans:
        mul = 1.0 if fixed else p.cam_anim_strength
        if name == "orbit":
            core.write_keys(rig, "rotation_euler", 2, [(f, math.radians(az + v), e) for f, v, e in points(keys, ease, f0, f1, 0.0, 1.0, mul)])
        elif name == "elev":
            core.write_keys(rig, "rotation_euler", 0, [(f, -math.radians(max(el + v, el_min)), e) for f, v, e in points(keys, ease, f0, f1, 0.0, 1.0, mul)])
        elif name == "dist":
            core.write_keys(cam, "location", 1, [(f, -dist * max(0.05, 1.0 + v), e) for f, v, e in points(keys, ease, f0, f1, 0.0, 1.0, mul)])
        elif name == "truck":
            pts = points(keys, ease, f0, f1, 0.0, R, mul)
            core.write_keys(rig, "location", 0, [(f, aim.x + right.x * v, e) for f, v, e in pts])
            core.write_keys(rig, "location", 1, [(f, aim.y + right.y * v, e) for f, v, e in pts])
        elif name == "ped":
            core.write_keys(rig, "location", 2, points(keys, ease, f0, f1, aim.z, R, mul))
        elif name == "lens":
            core.write_keys(cam.data, "lens", 0, [(f, max(4.0, lens * (1.0 + v)), e) for f, v, e in points(keys, ease, f0, f1, 0.0, 1.0, mul)])
        elif name == "focus":
            if not cam.data.dof.use_dof:
                with core.locked():
                    p.use_dof = True
                cam.data.dof.use_dof = True
            core.write_keys(focus, "location", 1, points(keys, ease, f0, f1, p.focus_offset * R, R, mul))
        elif name == "roll":
            core.write_keys(cam, "rotation_euler", 1, [(f, math.radians(p.cam_roll + v), e) for f, v, e in points(keys, ease, f0, f1, 0.0, 1.0, mul)])
        elif name == "tilt":
            core.write_keys(cam, "rotation_euler", 0, [(f, math.radians(90.0 + p.cam_tilt + v), e) for f, v, e in points(keys, ease, f0, f1, 0.0, 1.0, mul)])
    core.refresh(scene)
    return True


def apply_all(scene):
    a = apply_product_anim(scene)
    b = apply_camera_anim(scene)
    return a or b


def clear_all(scene):
    reset_product(scene)
    rig, cam, focus = reset_camera(scene)
    core.refresh(scene)
