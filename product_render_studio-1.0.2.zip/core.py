import bpy
import math
from contextlib import contextmanager
from mathutils import Vector

V5 = bpy.app.version >= (5, 0, 0)
ROOT_COLL = "Product Render Studio"
SUB_COLLS = {
    "product": "SR Product Rig",
    "stage": "SR Stage",
    "lights": "SR Lights",
    "camera": "SR Camera",
}

_lock = [0]


@contextmanager
def locked():
    _lock[0] += 1
    try:
        yield
    finally:
        _lock[0] -= 1


def is_locked():
    return _lock[0] > 0


def P(scene):
    return scene.product_render_studio


def eevee_id():
    return "BLENDER_EEVEE" if V5 else "BLENDER_EEVEE_NEXT"


def is_eevee(scene):
    return scene.render.engine in {"BLENDER_EEVEE", "BLENDER_EEVEE_NEXT"}


def collection(scene, key):
    root = bpy.data.collections.get(ROOT_COLL)
    if root is None:
        root = bpy.data.collections.new(ROOT_COLL)
    if root.name not in scene.collection.children:
        scene.collection.children.link(root)
    name = SUB_COLLS[key]
    sub = bpy.data.collections.get(name)
    if sub is None:
        sub = bpy.data.collections.new(name)
    if sub.name not in root.children:
        root.children.link(sub)
    return sub


def tagged(scene, *roles):
    return [o for o in scene.objects if o.get("sr_role") in roles]


def first(scene, role):
    for o in scene.objects:
        if o.get("sr_role") == role:
            return o
    return None


def remove_object(obj):
    data = obj.data
    bpy.data.objects.remove(obj, do_unlink=True)
    if data is None or data.users > 0:
        return
    if isinstance(data, bpy.types.Mesh):
        bpy.data.meshes.remove(data)
    elif isinstance(data, bpy.types.Light):
        bpy.data.lights.remove(data)
    elif isinstance(data, bpy.types.Camera):
        clear_anim(data)
        bpy.data.cameras.remove(data)


def remove_roles(scene, *roles):
    for o in tagged(scene, *roles):
        remove_object(o)


def new_object(scene, name, data, role, key, parent=None):
    obj = bpy.data.objects.new(name, data)
    obj["sr_role"] = role
    collection(scene, key).objects.link(obj)
    if parent is not None:
        obj.parent = parent
    return obj


def new_empty(scene, name, role, key, display="PLAIN_AXES", size=0.1, parent=None):
    obj = new_object(scene, name, None, role, key, parent)
    obj.empty_display_type = display
    obj.empty_display_size = size
    return obj


def set_ray_visibility(obj, camera=True, diffuse=True, glossy=True, shadow=True, transmission=True):
    obj.visible_camera = camera
    obj.visible_diffuse = diffuse
    obj.visible_glossy = glossy
    obj.visible_shadow = shadow
    obj.visible_transmission = transmission


def srgb_to_linear(c):
    return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4


def kelvin_rgb(k):
    t = max(1000.0, min(40000.0, float(k))) / 100.0
    if t <= 66:
        r = 255.0
        g = 99.4708025861 * math.log(t) - 161.1195681661
    else:
        r = 329.698727446 * ((t - 60) ** -0.1332047592)
        g = 288.1221695283 * ((t - 60) ** -0.0755148492)
    if t >= 66:
        b = 255.0
    elif t <= 19:
        b = 0.0
    else:
        b = 138.5177312231 * math.log(t - 10) - 305.0447927307
    rgb = [srgb_to_linear(max(0.0, min(255.0, c)) / 255.0) for c in (r, g, b)]
    m = max(rgb) or 1.0
    return Vector([c / m for c in rgb])


def hex_rgb(h):
    h = h.lstrip("#")
    return Vector([srgb_to_linear(int(h[i:i + 2], 16) / 255.0) for i in (0, 2, 4)])


def color_of(spec):
    if isinstance(spec, str):
        return hex_rgb(spec)
    return kelvin_rgb(spec)


def temperature_tint(shift):
    a = kelvin_rgb(6500 + shift)
    b = kelvin_rgb(6500)
    t = Vector([a[i] / max(b[i], 1e-4) for i in range(3)])
    m = max(t) or 1.0
    return t / m


def product_root(scene):
    p = P(scene)
    root = p.product_root
    if root is not None and root.name in scene.objects:
        return root
    return None


def product_part(scene, role):
    return first(scene, role)


def product_info(scene):
    p = P(scene)
    root = product_root(scene)
    if root is not None and p.prod_h > 0:
        base = root.matrix_world.translation.copy()
        dims = Vector((p.prod_w, p.prod_d, p.prod_h))
    else:
        base = Vector((0.0, 0.0, 0.0))
        dims = Vector((0.2, 0.2, 0.3))
    radius = max(0.5 * dims.length, 1e-3)
    center = base + Vector((0.0, 0.0, dims.z * 0.5))
    return {"base": base, "dims": dims, "R": radius, "center": center, "h": dims.z, "root": root}


def floor_z(scene):
    p = P(scene)
    info = product_info(scene)
    z = info["base"].z
    if p.podium_type != "NONE":
        z -= p.podium_height * info["R"]
    return z


def world_bbox(objs):
    mn = Vector((1e18, 1e18, 1e18))
    mx = Vector((-1e18, -1e18, -1e18))
    found = False
    for o in objs:
        if o.type in {"EMPTY", "LIGHT", "CAMERA", "SPEAKER", "LIGHT_PROBE", "LIGHTPROBE"}:
            continue
        for c in o.bound_box:
            w = o.matrix_world @ Vector(c)
            mn = Vector(map(min, mn, w))
            mx = Vector(map(max, mx, w))
            found = True
    if not found:
        return None
    return mn, mx


def find_in(node, key):
    for s in node.inputs:
        if s.identifier == key:
            return s
    for s in node.inputs:
        if s.name == key:
            return s
    return None


def put(node, keys, value, prop=None, pval=None):
    if isinstance(keys, str):
        keys = (keys,)
    for k in keys:
        s = find_in(node, k)
        if s is not None and hasattr(s, "default_value"):
            v = value
            try:
                n = len(s.default_value)
                if isinstance(v, (tuple, list, Vector)) and len(v) < n:
                    v = tuple(v) + (1.0,) * (n - len(v))
            except TypeError:
                pass
            try:
                s.default_value = v
                return True
            except (TypeError, ValueError, AttributeError):
                pass
    if prop and hasattr(node, prop):
        try:
            setattr(node, prop, value if pval is None else pval)
            return True
        except (TypeError, ValueError, AttributeError):
            pass
    return False


def out_sock(node, *keys):
    for k in keys:
        for s in node.outputs:
            if s.identifier == k or s.name == k:
                return s
    return node.outputs[0]


def material(name):
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name)
    if mat.node_tree is None:
        mat.use_nodes = True
    mat.node_tree.nodes.clear()
    return mat, mat.node_tree


def node(nt, kind, name=None, loc=(0, 0), **inputs):
    n = nt.nodes.new(kind)
    if name:
        n.name = name
        n.label = name.replace("SR_", "")
    n.location = loc
    for k, v in inputs.items():
        put(n, k.replace("_", " "), v)
    return n


def link(nt, a, b):
    nt.links.new(a, b)


def set_mesh(obj_or_mesh, verts, faces, smooth=False):
    me = obj_or_mesh
    me.clear_geometry()
    me.from_pydata([tuple(v) for v in verts], [], faces)
    me.update()
    if smooth:
        me.polygons.foreach_set("use_smooth", [True] * len(me.polygons))
    me.update()
    return me


def assign_material(obj, mat):
    obj.data.materials.clear()
    obj.data.materials.append(mat)


EASE = {
    "lin": ("LINEAR", "AUTO", "AUTO_CLAMPED"),
    "ease": ("BEZIER", "AUTO", "AUTO_CLAMPED"),
    "smooth": ("BEZIER", "AUTO", "AUTO"),
    "const": ("CONSTANT", "AUTO", "AUTO_CLAMPED"),
    "sine": ("SINE", "EASE_IN_OUT", "AUTO_CLAMPED"),
    "quad_in": ("QUAD", "EASE_IN", "AUTO_CLAMPED"),
    "quad_out": ("QUAD", "EASE_OUT", "AUTO_CLAMPED"),
    "cubic_io": ("CUBIC", "EASE_IN_OUT", "AUTO_CLAMPED"),
    "expo": ("EXPO", "EASE_OUT", "AUTO_CLAMPED"),
    "expo_in": ("EXPO", "EASE_IN", "AUTO_CLAMPED"),
    "expo_io": ("EXPO", "EASE_IN_OUT", "AUTO_CLAMPED"),
    "back": ("BACK", "EASE_OUT", "AUTO_CLAMPED"),
    "back_in": ("BACK", "EASE_IN", "AUTO_CLAMPED"),
    "elastic": ("ELASTIC", "EASE_OUT", "AUTO_CLAMPED"),
    "bounce": ("BOUNCE", "EASE_OUT", "AUTO_CLAMPED"),
    "circ": ("CIRC", "EASE_OUT", "AUTO_CLAMPED"),
}


def fcurve(id_data, path, index):
    ad = id_data.animation_data or id_data.animation_data_create()
    if ad.action is None:
        ad.action = bpy.data.actions.new("SR_" + id_data.name)
    act = ad.action
    if hasattr(act, "fcurve_ensure_for_datablock"):
        return act.fcurve_ensure_for_datablock(id_data, path, index=index)
    fc = act.fcurves.find(path, index=index)
    return fc if fc is not None else act.fcurves.new(path, index=index)


def write_keys(id_data, path, index, points):
    if not points:
        return
    fc = fcurve(id_data, path, index)
    kps = fc.keyframe_points
    while len(kps):
        kps.remove(kps[0], fast=True)
    kps.add(len(points))
    for kp, (frame, value, ease) in zip(kps, points):
        ip, easing, handle = EASE.get(ease, EASE["ease"])
        kp.co = (frame, value)
        kp.handle_left_type = handle
        kp.handle_right_type = handle
        kp.interpolation = ip
        kp.easing = easing
    fc.update()


def clear_anim(id_data):
    if id_data is None:
        return
    ad = id_data.animation_data
    if ad is None:
        return
    act = ad.action
    id_data.animation_data_clear()
    if act is not None and act.users == 0:
        bpy.data.actions.remove(act)


def refresh(scene):
    scene.frame_set(scene.frame_current)


def look_matrix(direction, track="-Z", up="Y"):
    return direction.to_track_quat(track, up).to_euler()


def sph(az_deg, el_deg):
    a = math.radians(az_deg)
    e = math.radians(el_deg)
    return Vector((math.sin(a) * math.cos(e), -math.cos(a) * math.cos(e), math.sin(e)))


def camera_az(scene):
    rig = first(scene, "cam_rig")
    if rig is not None and "sr_az" in rig:
        return float(rig["sr_az"])
    return 0.0


def tag_redraw():
    wm = bpy.context.window_manager if bpy.context else None
    if wm is None:
        return
    for win in wm.windows:
        for area in win.screen.areas:
            if area.type in {"VIEW_3D", "PROPERTIES", "NODE_EDITOR"}:
                area.tag_redraw()
