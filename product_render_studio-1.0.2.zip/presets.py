import math


def wave(amp, cycles=1.0, phase=0.0, offset=0.0, n=None, t0=0.0, t1=1.0):
    n = n or max(4, int(round(4 * cycles)))
    return [(t0 + (t1 - t0) * i / n, offset + amp * math.sin(2 * math.pi * (cycles * i / n + phase))) for i in range(n + 1)]


def damped(amp, cycles, t0=0.0, t1=1.0, decay=4.0, per=4):
    n = max(4, int(cycles * per))
    keys = []
    for i in range(n + 1):
        u = i / n
        keys.append((t0 + (t1 - t0) * u, amp * math.exp(-decay * u) * math.sin(2 * math.pi * cycles * u)))
    keys[-1] = (t1, 0.0)
    return keys


def jitter(amp, n, seed, t0=0.0, t1=1.0, end_zero=True):
    s = seed * 7919 + 17
    keys = []
    for i in range(n + 1):
        s = (s * 1103515245 + 12345) & 0x7FFFFFFF
        keys.append((t0 + (t1 - t0) * i / n, amp * ((s / 0x7FFFFFFF) * 2 - 1)))
    if end_zero:
        keys[0] = (t0, 0.0)
        keys[-1] = (t1, 0.0)
    return keys


def steps(total, n, t0=0.0, t1=1.0):
    return [(t0 + (t1 - t0) * i / n, total * i / n) for i in range(n + 1)]


def bounces(height, count, t0=0.0, t1=1.0):
    keys = []
    for i in range(count):
        a = t0 + (t1 - t0) * i / count
        m = t0 + (t1 - t0) * (i + 0.5) / count
        keys.append((a, 0.0, "quad_out"))
        keys.append((m, height, "quad_in"))
    keys.append((t1, 0.0, "quad_out"))
    return keys


def heartbeat(amp, beats):
    keys = [(0.0, 0.0)]
    for b in range(beats):
        o = b / beats
        d = 1.0 / beats
        keys += [(o + d * 0.08, amp), (o + d * 0.18, 0.0), (o + d * 0.28, amp * 0.6), (o + d * 0.42, 0.0)]
    keys.append((1.0, 0.0))
    return keys


def C(ch, keys, ease="ease", fixed=False):
    return (ch, keys, ease, fixed)


PRODUCT_ANIMS = [
    ("NONE", "None", "Basics", False, []),
    ("TURN_360", "Turntable 360", "Spins", True, [C("rz", [(0, 0), (1, 360)], "lin", True)]),
    ("TURN_360_EASE", "Turntable Eased", "Spins", False, [C("rz", [(0, 0), (1, 360)], "sine", True)]),
    ("TURN_180", "Half Turn Glide", "Spins", False, [C("rz", [(0, -90), (1, 90)], "sine", True)]),
    ("QUARTER_SETTLE", "Quarter Turn Settle", "Spins", False, [C("rz", [(0, -90), (0.7, 0)], "back", True)]),
    ("WHIP_SETTLE", "Whip Spin Settle", "Spins", False, [C("rz", [(0, -720), (0.85, 0)], "expo", True)]),
    ("DOUBLE_SPIN", "Double Spin", "Spins", True, [C("rz", [(0, 0), (1, 720)], "lin", True)]),
    ("REVERSE_TURN", "Reverse Turntable", "Spins", True, [C("rz", [(0, 0), (1, -360)], "lin", True)]),
    ("TILTED_SPIN", "Tilted Spin", "Spins", True, [
        C("rz", [(0, 0), (1, 360)], "lin", True),
        C("brx", [(0, -12), (1, -12)], "lin"),
        C("z", [(0, 0.35), (1, 0.35)], "lin"),
    ]),
    ("SPIN_RISE", "Spin & Rise", "Spins", False, [
        C("rz", [(0, 0), (1, 360)], "sine", True),
        C("z", [(0, 0), (1, 0.6)], "sine"),
    ]),
    ("WOBBLE_SPIN", "Wobble Spin", "Spins", True, [
        C("rz", [(0, 0), (1, 360)], "lin", True),
        C("brx", wave(5, 2), "smooth"),
        C("bry", wave(5, 2, 0.25), "smooth"),
    ]),
    ("STEP_TURN", "Snap Step Turn", "Spins", True, [C("rz", [(t, v, "back") for t, v in steps(360, 8)], "back", True)]),
    ("STOP_MOTION", "Stop-Motion Turn", "Spins", True, [C("rz", steps(360, 12), "const", True)]),

    ("HOVER_BOB", "Hover Bob", "Drifts", True, [
        C("z", wave(0.08, 2, offset=0.3), "smooth"),
        C("rz", [(0, -8), (1, 8)], "sine"),
    ]),
    ("LEVITATE_TURN", "Levitate & Turn", "Drifts", False, [
        C("z", [(0, 0), (0.35, 0.4)], "cubic_io"),
        C("rz", [(0, 0), (1, 180)], "sine", True),
    ]),
    ("DRIFT_LEFT", "Slow Drift Left", "Drifts", False, [
        C("x", [(0, 0.6), (1, -0.6)], "lin"),
        C("rz", [(0, 10), (1, -10)], "lin"),
    ]),
    ("DRIFT_RIGHT", "Slow Drift Right", "Drifts", False, [
        C("x", [(0, -0.6), (1, 0.6)], "lin"),
        C("rz", [(0, -10), (1, 10)], "lin"),
    ]),
    ("DRIFT_UP", "Drift Up", "Drifts", False, [
        C("z", [(0, 0), (1, 0.7)], "lin"),
        C("rz", [(0, -15), (1, 15)], "lin"),
    ]),
    ("DRIFT_TOWARD", "Drift Toward Lens", "Drifts", False, [
        C("y", [(0, 1.2), (1, -0.4)], "lin"),
        C("rz", [(0, 12), (1, -6)], "lin"),
    ]),
    ("DRIFT_AWAY", "Drift Away", "Drifts", False, [
        C("y", [(0, -0.4), (1, 1.4)], "lin"),
        C("rz", [(0, -6), (1, 12)], "lin"),
    ]),
    ("HOVER_SWAY", "Hover Sway", "Drifts", True, [
        C("z", wave(0.06, 2, offset=0.3), "smooth"),
        C("ry", wave(6, 1), "smooth"),
        C("rx", wave(4, 1, 0.25), "smooth"),
    ]),
    ("ZERO_G", "Zero-G Tumble", "Drifts", False, [
        C("z", wave(0.08, 1, offset=0.45), "smooth"),
        C("rx", [(0, -20), (1, 25)], "lin"),
        C("ry", [(0, 10), (1, -30)], "lin"),
        C("rz", [(0, 0), (1, 90)], "lin", True),
    ]),
    ("GENTLE_ORBIT", "Gentle Orbit", "Drifts", True, [
        C("x", wave(0.25, 1, n=8), "smooth"),
        C("y", wave(0.25, 1, 0.25, n=8), "smooth"),
        C("rz", [(0, 0), (1, 40)], "lin"),
    ]),

    ("RISE_FLOOR", "Rise From Floor", "Reveals", False, [C("zh", [(0, -1.05), (0.7, 0)], "expo")]),
    ("POP_IN", "Scale Pop-In", "Reveals", False, [C("bs", [(0, -0.999), (0.45, 0)], "back", True)]),
    ("GROW_BASE", "Grow From Base", "Reveals", False, [
        C("bs", [(0, -0.999), (0.6, 0)], "expo", True),
        C("rz", [(0, -60), (0.6, 0)], "expo", True),
    ]),
    ("SLIDE_IN_LEFT", "Slide In Left", "Reveals", False, [
        C("x", [(0, -4), (0.55, 0)], "expo"),
        C("rz", [(0, -35), (0.55, 0)], "expo"),
    ]),
    ("SLIDE_IN_RIGHT", "Slide In Right", "Reveals", False, [
        C("x", [(0, 4), (0.55, 0)], "expo"),
        C("rz", [(0, 35), (0.55, 0)], "expo"),
    ]),
    ("DESCEND", "Descend From Above", "Reveals", False, [
        C("z", [(0, 4), (0.6, 0)], "expo"),
        C("rz", [(0, 90), (0.6, 0)], "expo"),
    ]),
    ("SPIN_REVEAL", "Spin Reveal", "Reveals", False, [
        C("bs", [(0, -0.999), (0.5, 0)], "back", True),
        C("rz", [(0, -360), (0.7, 0)], "expo", True),
    ]),
    ("TILT_SETTLE", "Tilt Settle", "Reveals", False, [C("brx", [(0, -25), (0.8, 0)], "elastic")]),
    ("TWIST_REVEAL", "Twist Reveal", "Reveals", False, [
        C("rz", [(0, -180), (0.7, 0)], "expo", True),
        C("s", [(0, -0.4), (0.7, 0)], "expo"),
        C("z", [(0, 1.0), (0.7, 0)], "expo"),
    ]),
    ("EMERGE_DEPTH", "Emerge From Depth", "Reveals", False, [
        C("y", [(0, 6), (0.7, 0)], "expo"),
        C("rz", [(0, 45), (0.7, 0)], "expo"),
    ]),

    ("DROP_BOUNCE", "Drop & Bounce", "Drops", False, [C("z", [(0, 3), (0.6, 0)], "bounce")]),
    ("DROP_SETTLE", "Drop & Squash", "Drops", False, [
        C("z", [(0, 2.5, "quad_in"), (0.42, 0)], "quad_in"),
        C("bsz", [(0.42, 0), (0.48, -0.16), (0.6, 0.05), (0.7, 0)], "ease"),
        C("bsx", [(0.42, 0), (0.48, 0.08), (0.6, -0.025), (0.7, 0)], "ease"),
        C("bsy", [(0.42, 0), (0.48, 0.08), (0.6, -0.025), (0.7, 0)], "ease"),
    ]),
    ("HEAVY_DROP", "Heavy Impact", "Drops", False, [
        C("z", [(0, 3, "quad_in"), (0.35, 0)], "quad_in"),
        C("brx", [(0.35, 0), (0.4, -3), (0.47, 2), (0.55, -0.8), (0.62, 0)], "ease"),
        C("bsz", [(0.35, 0), (0.39, -0.08), (0.48, 0)], "ease"),
    ]),
    ("DROP_SPIN", "Spin Drop", "Drops", False, [
        C("z", [(0, 3), (0.6, 0)], "bounce"),
        C("rz", [(0, -270), (0.6, 0)], "expo", True),
    ]),
    ("TILT_LANDING", "Tilt Landing", "Drops", False, [
        C("z", [(0, 2.5, "quad_in"), (0.4, 0)], "quad_in"),
        C("brx", [(0, 18), (0.4, 18), (0.52, -5), (0.66, 1.5), (0.8, 0)], "ease"),
        C("bry", [(0, -8), (0.4, -8), (0.52, 3), (0.66, -1), (0.8, 0)], "ease"),
    ]),
    ("BOUNCE_LOOP", "Bounce Loop", "Drops", True, [C("z", bounces(0.8, 3), "quad_out")]),

    ("FRONT_FLIP", "Front Flip", "Flips", False, [
        C("rx", [(0, 0), (1, 360)], "cubic_io", True),
        C("zh", [(0, 0, "quad_out"), (0.5, 0.75, "quad_in"), (1, 0)], "quad_out"),
    ]),
    ("BACK_FLIP", "Back Flip", "Flips", False, [
        C("rx", [(0, 0), (1, -360)], "cubic_io", True),
        C("zh", [(0, 0, "quad_out"), (0.5, 0.75, "quad_in"), (1, 0)], "quad_out"),
    ]),
    ("SIDE_FLIP", "Side Flip", "Flips", False, [
        C("ry", [(0, 0), (1, 360)], "cubic_io", True),
        C("zh", [(0, 0, "quad_out"), (0.5, 0.75, "quad_in"), (1, 0)], "quad_out"),
    ]),
    ("FLIP_LAND", "Flip & Land", "Flips", False, [
        C("z", [(0, 3.5, "quad_in"), (0.55, 0)], "quad_in"),
        C("rx", [(0, -360), (0.55, 0)], "expo", True),
        C("bsz", [(0.55, 0), (0.6, -0.12), (0.72, 0)], "ease"),
    ]),
    ("COIN_FLIP", "Coin Flip", "Flips", False, [
        C("zh", [(0, 0, "quad_out"), (0.5, 1.3, "quad_in"), (1, 0)], "quad_out"),
        C("rx", [(0, 0), (1, 720)], "lin", True),
    ]),
    ("BARREL_ROLL", "Barrel Roll", "Flips", False, [
        C("ry", [(0, 0), (1, 360)], "cubic_io", True),
        C("x", [(0, -1.2), (1, 1.2)], "sine"),
        C("z", [(0, 0.3), (0.5, 0.7), (1, 0.3)], "smooth"),
    ]),

    ("CIRCLE_ORBIT", "Circle Orbit", "Orbits", True, [
        C("x", wave(1.0, 1, n=8), "smooth"),
        C("y", wave(1.0, 1, 0.25, n=8), "smooth"),
        C("rz", [(0, 0), (1, 360)], "lin", True),
    ]),
    ("FIGURE_EIGHT", "Figure Eight", "Orbits", True, [
        C("x", wave(1.0, 1, n=16), "smooth"),
        C("y", wave(0.5, 2, n=16), "smooth"),
    ]),
    ("ROCK", "Rock Back & Forth", "Orbits", True, [C("brx", wave(9, 2), "smooth")]),
    ("PENDULUM", "Pendulum Swing", "Orbits", True, [
        C("ry", wave(16, 1.5), "smooth"),
        C("x", wave(0.3, 1.5), "smooth"),
        C("z", [(0, 0.35), (1, 0.35)], "lin"),
    ]),
    ("SHOWCASE_ROCK", "Showcase Rock & Turn", "Orbits", True, [
        C("rz", [(0, -35), (0.5, 35), (1, -35)], "sine"),
        C("brx", wave(3, 2), "smooth"),
    ]),
    ("PLANET_ORBIT", "Planet Orbit", "Orbits", True, [
        C("x", wave(0.8, 1, n=8), "smooth"),
        C("y", wave(0.8, 1, 0.25, n=8), "smooth"),
        C("z", wave(0.15, 1, 0.5, offset=0.4, n=8), "smooth"),
        C("rz", [(0, 0), (1, 360)], "lin", True),
    ]),

    ("FLYBY_LR", "Fly-By Left to Right", "Fly-Bys", False, [
        C("x", [(0, -6), (1, 6)], "lin"),
        C("rz", [(0, -30), (1, 30)], "lin"),
        C("z", [(0, 0.3), (1, 0.3)], "lin"),
    ]),
    ("FLY_TOWARD", "Fly Toward Lens", "Fly-Bys", False, [
        C("y", [(0, 8), (1, -2.2)], "lin"),
        C("rz", [(0, 90), (1, 0)], "lin"),
    ]),
    ("SWOOP_IN", "Swoop In", "Fly-Bys", False, [
        C("x", [(0, -5), (0.7, 0)], "expo"),
        C("z", [(0, 3), (0.7, 0)], "sine"),
        C("rz", [(0, -120), (0.7, 0)], "expo", True),
        C("ry", [(0, 25), (0.7, 0)], "expo"),
    ]),
    ("ARC_PASS", "Arc Pass", "Fly-Bys", False, [
        C("x", [(0, -4), (1, 4)], "lin"),
        C("y", [(0, 2), (0.5, -0.5), (1, 2)], "smooth"),
        C("rz", [(0, 60), (1, -60)], "lin"),
    ]),
    ("LAUNCH_EXIT", "Launch Exit", "Fly-Bys", False, [
        C("z", [(0, 0), (0.35, 0, "expo_in"), (1, 9)], "lin"),
        C("rz", [(0, 0), (0.35, 0, "quad_in"), (1, 180)], "lin", True),
        C("bsz", [(0, 0), (0.22, 0), (0.33, -0.1), (0.4, 0.08), (0.5, 0)], "ease"),
    ]),
    ("HOLD_EXIT", "Hero Hold & Exit", "Fly-Bys", False, [C("x", [(0, 0), (0.6, 0, "back_in"), (1, -6)], "back_in")]),

    ("HEARTBEAT", "Heartbeat Pulse", "Stylized", True, [C("bs", heartbeat(0.07, 2), "ease")]),
    ("JELLY", "Jelly Wobble", "Stylized", False, [
        C("bsz", damped(0.14, 4, 0.0, 0.8, 3.5), "smooth"),
        C("bsx", [(t, -v * 0.5) for t, v in damped(0.14, 4, 0.0, 0.8, 3.5)], "smooth"),
        C("bsy", [(t, -v * 0.5) for t, v in damped(0.14, 4, 0.0, 0.8, 3.5)], "smooth"),
    ]),
    ("GLITCH", "Glitch Jitter", "Stylized", False, [
        C("x", jitter(0.12, 24, 3), "const"),
        C("rz", jitter(6, 24, 5), "const"),
        C("bs", jitter(0.05, 24, 9), "const"),
    ]),
    ("BREATHE", "Breathing Scale", "Stylized", True, [C("bs", wave(0.035, 2), "smooth")]),
    ("IMPACT_SHAKE", "Impact Shake", "Stylized", False, [
        C("x", damped(0.12, 6, 0.0, 0.5, 5.0), "smooth"),
        C("brz", damped(2.5, 6, 0.0, 0.5, 5.0), "smooth"),
    ]),
    ("HERO_MOMENT", "Hero Moment", "Stylized", False, [
        C("bs", [(0, -0.08), (1, 0.03)], "sine"),
        C("rz", [(0, -15), (1, 10)], "sine"),
        C("zh", [(0, 0), (1, 0.05)], "sine"),
    ]),
    ("DRAMATIC_TILT", "Dramatic Tilt", "Stylized", False, [
        C("brx", [(0, 0), (0.5, -12), (1, 0)], "sine"),
        C("rz", [(0, -20), (1, 20)], "sine"),
    ]),
    ("SNAP_SCALE", "Snap Scale", "Stylized", False, [
        C("bs", [(0, -0.3, "back"), (0.25, 0, "back"), (0.5, 0.12, "back"), (0.75, 0)], "back"),
    ]),
]

CAMERA_ANIMS = [
    ("STATIC", "Locked Off", "Basics", False, []),
    ("PUSH_SLOW", "Slow Push-In", "Push & Pull", False, [C("dist", [(0, 0.15), (1, -0.12)], "sine")]),
    ("PUNCH_IN", "Punch-In", "Push & Pull", False, [C("dist", [(0, 0.3), (0.5, -0.12)], "expo")]),
    ("PULL_BACK", "Pull-Back", "Push & Pull", False, [C("dist", [(0, -0.25), (1, 0.15)], "sine")]),
    ("MACRO_PULL", "Macro Pull Reveal", "Push & Pull", False, [
        C("dist", [(0, -0.6), (1, 0.05)], "cubic_io"),
        C("elev", [(0, -4), (1, 2)], "cubic_io"),
    ]),
    ("DOLLY_ZOOM", "Dolly Zoom", "Push & Pull", False, [
        C("dist", [(0, -0.35), (1, 0.6)], "sine"),
        C("lens", [(0, -0.35), (1, 0.6)], "sine"),
    ]),
    ("LENS_ZOOM", "Lens Zoom", "Push & Pull", False, [C("lens", [(0, -0.3), (1, 0.25)], "sine")]),
    ("ORBIT_LEFT", "Orbit 90 Left", "Orbits", False, [C("orbit", [(0, 45), (1, -45)], "sine")]),
    ("ORBIT_RIGHT", "Orbit 90 Right", "Orbits", False, [C("orbit", [(0, -45), (1, 45)], "sine")]),
    ("ORBIT_360", "Orbit 360", "Orbits", True, [C("orbit", [(0, 0), (1, 360)], "lin", True)]),
    ("ORBIT_HALF", "Half Orbit", "Orbits", False, [C("orbit", [(0, -90), (1, 90)], "cubic_io")]),
    ("ORBIT_PUSH", "Orbit + Push", "Orbits", False, [
        C("orbit", [(0, -40), (1, 30)], "sine"),
        C("dist", [(0, 0.2), (1, -0.1)], "sine"),
    ]),
    ("WHIP_ORBIT", "Whip Orbit", "Orbits", False, [
        C("orbit", [(0, -150), (0.6, 0)], "expo"),
        C("dist", [(0, 0.3), (0.6, 0)], "expo"),
    ]),
    ("CRANE_UP", "Crane Up", "Crane", False, [C("elev", [(0, -12), (1, 25)], "sine")]),
    ("CRANE_DOWN", "Crane Down", "Crane", False, [C("elev", [(0, 35), (1, -5)], "sine")]),
    ("RISING_ORBIT", "Rising Orbit", "Crane", False, [
        C("orbit", [(0, -60), (1, 60)], "sine"),
        C("elev", [(0, -8), (1, 25)], "sine"),
    ]),
    ("SPIRAL_DOWN", "Top-Down Spiral", "Crane", False, [
        C("elev", [(0, 60), (1, 0)], "sine"),
        C("orbit", [(0, -90), (1, 30)], "sine"),
        C("dist", [(0, 0.3), (1, 0)], "sine"),
    ]),
    ("FLY_OVER", "Fly-Over", "Crane", False, [
        C("elev", [(0, 0), (1, 75)], "cubic_io"),
        C("dist", [(0, 0), (0.5, -0.1), (1, 0.05)], "smooth"),
    ]),
    ("ARC_REVEAL", "Low Arc Reveal", "Crane", False, [
        C("elev", [(0, -6), (1, 16)], "cubic_io"),
        C("orbit", [(0, -70), (1, 0)], "cubic_io"),
    ]),
    ("TRUCK_LEFT", "Truck Left", "Slides", False, [C("truck", [(0, 0.8), (1, -0.8)], "sine")]),
    ("TRUCK_RIGHT", "Truck Right", "Slides", False, [C("truck", [(0, -0.8), (1, 0.8)], "sine")]),
    ("PEDESTAL_UP", "Pedestal Up", "Slides", False, [C("ped", [(0, -0.6), (1, 0.4)], "sine")]),
    ("MACRO_GLIDE", "Macro Glide", "Slides", False, [C("truck", [(0, 0.35), (1, -0.35)], "lin")]),
    ("TILT_REVEAL", "Tilt-Up Reveal", "Slides", False, [C("tilt", [(0, -18), (0.8, 0)], "cubic_io")]),
    ("RACK_FOCUS", "Rack Focus", "Focus", False, [C("focus", [(0, -1.2), (0.35, -1.2), (0.65, 0.9), (1, 0.9)], "ease")]),
    ("HANDHELD", "Handheld Drift", "Focus", True, [
        C("tilt", jitter(0.6, 10, 11), "smooth"),
        C("roll", jitter(0.5, 9, 13), "smooth"),
        C("orbit", jitter(0.8, 8, 17), "smooth"),
    ]),
    ("DUTCH_ROLL", "Dutch Roll", "Focus", False, [
        C("roll", [(0, -10), (1, 10)], "sine"),
        C("orbit", [(0, -10), (1, 10)], "sine"),
    ]),
]


def L(label, kind, az, el, dist, sx, sy, power, color, spread=0.0):
    return (label, kind, az, el, dist, sx, sy, power, color, spread)


LIGHT_PRESETS = [
    ("THREE_POINT", "Three-Point Classic", "Studio", "#1a1a1a", 0.15, [
        L("Key", "A", -45, 35, 4.5, 2.5, 2.5, 1.0, 5600),
        L("Fill", "A", 55, 15, 5, 3, 3, 0.3, 5600),
        L("Rim", "A", 165, 40, 4, 1, 3, 2.0, 6500),
    ]),
    ("HIGH_KEY", "High-Key White", "Studio", "#ffffff", 0.8, [
        L("Key", "A", -30, 35, 5, 5, 5, 0.7, 6000),
        L("Fill", "A", 40, 20, 5, 5, 5, 0.5, 6000),
        L("Top", "A", 0, 80, 5, 5, 5, 0.45, 6000),
        L("Back", "A", 180, 20, 5, 6, 4, 0.5, 6000),
    ]),
    ("BUTTERFLY", "Butterfly", "Studio", "#151515", 0.15, [
        L("Key", "D", 0, 50, 4, 2.5, 2.5, 1.2, 5600),
        L("Rim", "A", 180, 30, 4, 1, 3, 1.0, 6500),
    ]),
    ("OVERCAST", "Overcast Softbox", "Studio", "#808080", 0.4, [
        L("Top", "A", 0, 70, 5, 7, 7, 1.0, 6500),
        L("Front", "A", 0, 15, 6, 6, 3, 0.3, 6500),
    ]),
    ("SOFT_BEAUTY", "Soft Beauty", "Beauty", "#202020", 0.25, [
        L("Key", "A", -10, 40, 4, 4, 3, 0.9, 5600),
        L("Under Fill", "A", 0, -5, 3.5, 3, 1.2, 0.3, 5600),
        L("Strip L", "A", -120, 20, 4, 0.5, 4, 1.2, 6000),
        L("Strip R", "A", 120, 20, 4, 0.5, 4, 1.2, 6000),
    ]),
    ("CLAMSHELL", "Clamshell", "Beauty", "#181818", 0.2, [
        L("Top", "A", 0, 45, 4, 3.5, 2, 1.0, 5600),
        L("Bottom", "A", 0, -5, 3.5, 3, 1, 0.45, 5600),
        L("Hair", "A", 180, 55, 4, 2, 1, 1.2, 6500),
    ]),
    ("COSMETIC_GLOW", "Cosmetic Glow", "Beauty", "#2a2024", 0.3, [
        L("Key", "A", 0, 30, 4, 4, 3, 0.8, 5800),
        L("Strip L", "A", -130, 20, 3.5, 0.5, 4, 1.3, "#ffe4ec"),
        L("Strip R", "A", 130, 20, 3.5, 0.5, 4, 1.3, "#ffe4ec"),
        L("Under", "A", 0, -5, 3.5, 3, 0.8, 0.25, 6000),
    ]),
    ("SKINCARE_FRESH", "Skincare Fresh", "Beauty", "#e8eef0", 0.6, [
        L("Key", "A", -25, 40, 5, 5, 4, 0.8, 6200),
        L("Fill", "A", 45, 15, 5, 4, 4, 0.45, 6500),
        L("Rim", "A", 170, 25, 4, 1, 4, 1.0, 8000),
    ]),
    ("REMBRANDT", "Rembrandt", "Dramatic", "#0a0a0a", 0.05, [
        L("Key", "A", -50, 40, 4, 2, 2, 1.3, 5000),
        L("Kicker", "A", 140, 25, 4, 0.6, 3, 0.8, 6500),
    ]),
    ("SPLIT", "Split Light", "Dramatic", "#080808", 0.03, [
        L("Key", "A", -90, 10, 4, 2, 3, 1.4, 5600),
    ]),
    ("LOW_KEY", "Low-Key Moody", "Dramatic", "#050505", 0.02, [
        L("Key", "A", -60, 30, 4.5, 1.5, 2, 1.2, 4500),
        L("Rim", "A", 150, 35, 4, 0.5, 3, 2.2, 7000),
    ]),
    ("SILHOUETTE", "Silhouette Backlight", "Dramatic", "#000000", 0.0, [
        L("Wall Glow", "B", 180, 5, 1.4, 90, 1.0, 6.0, 6500),
        L("Edge L", "A", -150, 25, 4, 0.4, 3, 1.5, 6500),
        L("Edge R", "A", 150, 25, 4, 0.4, 3, 1.5, 6500),
    ]),
    ("TOP_DRAMA", "Top Light Drama", "Dramatic", "#050505", 0.02, [
        L("Top", "A", 0, 85, 4, 2.5, 2.5, 1.6, 5600),
        L("Rim", "A", 180, 30, 4, 1, 2, 0.8, 6500),
    ]),
    ("WINDOW", "Window Light", "Lifestyle", "#5a6070", 0.3, [
        L("Window", "A", -75, 25, 5, 4, 5, 1.4, 5200),
        L("Bounce", "A", 80, 10, 5, 4, 4, 0.15, 5000),
    ]),
    ("INTERIOR_DAY", "Interior Daylight", "Lifestyle", "#8aa4c8", 0.6, [
        L("Sun", "U", -60, 35, 6, 2, 0, 2.5, 5600),
        L("Window", "A", -80, 20, 5, 5, 5, 0.5, 6500),
        L("Bounce", "A", 90, 5, 5, 4, 4, 0.1, 4500),
    ]),
    ("FOOD_WARM", "Food Warm Window", "Lifestyle", "#2a2018", 0.2, [
        L("Window", "A", 150, 30, 4.5, 3, 3, 1.6, 4800),
        L("Fill", "A", -30, 20, 5, 3, 3, 0.35, 5000),
        L("Bounce", "A", 0, 5, 4, 2, 1, 0.15, 4500),
    ]),
    ("TWIN_STRIPS", "Twin Strips", "Strips", "#0d0d0d", 0.05, [
        L("Strip L", "A", -115, 15, 3.5, 0.35, 4.5, 1.6, 6500),
        L("Strip R", "A", 115, 15, 3.5, 0.35, 4.5, 1.6, 6500),
        L("Front Fill", "A", 0, 20, 6, 3, 2, 0.15, 6000),
    ]),
    ("HARD_STRIPS", "Hard Strip Contrast", "Strips", "#050505", 0.02, [
        L("Strip L", "A", -100, 10, 3, 0.25, 4, 2.0, 6500, 40),
        L("Strip R", "A", 100, 10, 3, 0.25, 4, 2.0, 6500, 40),
        L("Top Strip", "A", 0, 70, 3.5, 4, 0.3, 1.0, 6500, 40),
    ]),
    ("EDGE_LUX", "Luxury Edge Strips", "Strips", "#000000", 0.0, [
        L("Edge L", "A", -140, 15, 3.2, 0.15, 5, 2.5, 6000, 30),
        L("Edge R", "A", 140, 15, 3.2, 0.15, 5, 2.5, 6000, 30),
        L("Top Kicker", "A", 180, 70, 3.5, 2, 0.2, 1.2, 6000),
    ]),
    ("OVERHEAD_STRIP", "Overhead Strip", "Strips", "#101010", 0.05, [
        L("Top", "A", 0, 75, 3, 5, 0.5, 1.6, 6500),
        L("Back", "A", 180, 25, 4, 3, 0.4, 1.2, 6500),
    ]),
    ("TRIPLE_GLOSS", "Triple Strip Gloss", "Strips", "#0a0a0a", 0.03, [
        L("Left", "A", -70, 20, 3.5, 0.4, 5, 1.2, 6500),
        L("Center", "A", 0, 30, 4, 0.5, 5, 0.6, 6500),
        L("Right", "A", 70, 20, 3.5, 0.4, 5, 1.2, 6500),
        L("Rim", "A", 180, 40, 4, 2, 0.3, 1.0, 7000),
    ]),
    ("WRAP_STRIPS", "Wraparound Strips", "Strips", "#0a0a0a", 0.03, [
        L("Left", "A", -90, 15, 3.5, 0.5, 5, 1.3, 6000),
        L("Right", "A", 90, 15, 3.5, 0.5, 5, 1.3, 6000),
        L("Back", "A", 180, 15, 3.5, 0.5, 5, 1.5, 6500),
        L("Front", "A", 0, 25, 5, 2, 2, 0.3, 5600),
    ]),
    ("HALO_RING", "Halo Ring", "Halo", "#050505", 0.02, [
        L("Halo", "H", 180, 0, 2.5, 1.1, 0.03, 1.0, 6500),
        L("Key", "A", -30, 35, 4.5, 2, 2, 0.6, 5600),
    ]),
    ("HALO_DARK", "Halo Glow Dark", "Halo", "#000000", 0.0, [
        L("Halo", "H", 180, 0, 2, 1.0, 0.05, 2.0, 6000),
        L("Front", "A", 0, 20, 6, 2, 1, 0.08, 6000),
    ]),
    ("DOUBLE_HALO", "Double Halo", "Halo", "#030303", 0.01, [
        L("Inner Halo", "H", 180, 0, 2, 0.95, 0.025, 1.2, 6500),
        L("Outer Halo", "H", 180, 0, 3, 1.4, 0.02, 0.8, 6500),
        L("Key", "A", -35, 35, 4.5, 2, 2, 0.5, 5600),
    ]),
    ("HALO_WARM", "Warm Halo Backlight", "Halo", "#0a0705", 0.02, [
        L("Halo", "H", 180, 0, 2.2, 1.05, 0.04, 1.5, 3200),
        L("Key", "A", 35, 30, 4.5, 2, 2, 0.5, 4500),
        L("Wall Glow", "B", 180, 0, 1.2, 70, 1.0, 2.0, 3000),
    ]),
    ("PRISM", "Prism Dispersion", "Colour", "#050505", 0.02, [
        L("Red L", "A", -135, 15, 3.3, 0.18, 4.5, 1.5, "#ff1a1a", 60),
        L("Green L", "A", -122, 15, 3.3, 0.18, 4.5, 1.5, "#1aff3c", 60),
        L("Blue L", "A", -109, 15, 3.3, 0.18, 4.5, 1.5, "#2a3cff", 60),
        L("Red R", "A", 135, 15, 3.3, 0.18, 4.5, 1.5, "#ff1a1a", 60),
        L("Green R", "A", 122, 15, 3.3, 0.18, 4.5, 1.5, "#1aff3c", 60),
        L("Blue R", "A", 109, 15, 3.3, 0.18, 4.5, 1.5, "#2a3cff", 60),
        L("Key", "A", 0, 30, 5, 2, 2, 0.3, 6500),
    ]),
    ("NEON_CYBER", "Neon Cyberpunk", "Colour", "#05010a", 0.03, [
        L("Magenta", "A", -120, 20, 3.5, 0.4, 4, 2.0, "#ff1aa8"),
        L("Cyan", "A", 120, 20, 3.5, 0.4, 4, 2.0, "#17e6ff"),
        L("Front", "A", 0, 30, 5, 2, 2, 0.2, "#a07cff"),
        L("Neon Tube", "N", 165, 0, 5, 3.0, 0.03, 2.5, "#ff1aa8"),
    ]),
    ("TEAL_ORANGE", "Teal & Orange", "Colour", "#061014", 0.05, [
        L("Key", "A", -40, 30, 4.5, 2.5, 2.5, 1.1, "#ffae5c"),
        L("Rim", "A", 150, 30, 4, 0.6, 3, 2.0, "#2fd6d0"),
        L("Fill", "A", 60, 10, 5, 3, 3, 0.2, "#3a8fa0"),
    ]),
    ("SUNSET", "Golden Sunset", "Colour", "#1a0c14", 0.1, [
        L("Low Sun", "A", -70, 12, 5, 3, 2, 1.4, 2800),
        L("Sky", "A", 60, 40, 5, 4, 4, 0.35, "#7a5cff"),
        L("Rim", "A", 170, 15, 4, 1, 3, 1.0, 3200),
    ]),
    ("ARCTIC", "Arctic Cool", "Colour", "#0a1420", 0.15, [
        L("Key", "A", -30, 40, 4.5, 3, 3, 1.0, 9000),
        L("Rim", "A", 160, 30, 4, 0.6, 3, 1.6, 12000),
        L("Fill", "A", 50, 10, 5, 3, 3, 0.25, 8000),
    ]),
    ("DUOTONE", "Duotone Pop", "Colour", "#0a0a0a", 0.05, [
        L("Pink", "A", -80, 25, 4, 3, 3, 1.3, "#ff4fa3"),
        L("Blue", "A", 80, 25, 4, 3, 3, 1.3, "#3d7bff"),
    ]),
    ("HOLOGRAPHIC", "Holographic", "Colour", "#08060c", 0.03, [
        L("Hue 1", "P", -150, 20, 3.5, 0.3, 0, 0.8, "#ff3b3b"),
        L("Hue 2", "P", -90, 40, 3.5, 0.3, 0, 0.8, "#ffb43b"),
        L("Hue 3", "P", -30, 20, 3.5, 0.3, 0, 0.6, "#c8ff3b"),
        L("Hue 4", "P", 30, 40, 3.5, 0.3, 0, 0.6, "#3bffc8"),
        L("Hue 5", "P", 90, 20, 3.5, 0.3, 0, 0.8, "#3b8bff"),
        L("Hue 6", "P", 150, 40, 3.5, 0.3, 0, 0.8, "#c43bff"),
    ]),
    ("DARK_CONTOUR", "Dark Luxury Contour", "Luxury", "#000000", 0.0, [
        L("Contour L", "A", -130, 20, 3.5, 0.3, 4, 2.2, 5800, 50),
        L("Contour R", "A", 130, 20, 3.5, 0.3, 4, 2.2, 5800, 50),
        L("Top Kicker", "A", 180, 65, 3.5, 2.5, 0.4, 1.2, 6000),
        L("Logo Spot", "S", 0, 25, 5, 18, 0.6, 0.5, 5600),
    ]),
    ("GOLD_ACCENT", "Gold Accent", "Luxury", "#050302", 0.01, [
        L("Rim L", "A", -140, 20, 3.5, 0.4, 4, 2.0, 2900),
        L("Rim R", "A", 140, 20, 3.5, 0.4, 4, 2.0, 2900),
        L("Key", "A", 20, 35, 5, 2, 2, 0.5, 6500),
    ]),
    ("NOIR_SPOT", "Noir Spotlight", "Luxury", "#000000", 0.0, [
        L("Spot", "S", 10, 70, 4.5, 22, 0.35, 1.6, 5200),
        L("Rim", "A", 180, 25, 4, 0.3, 2.5, 0.9, 6500),
    ]),
    ("VELVET_NIGHT", "Velvet Night", "Luxury", "#06030a", 0.03, [
        L("Key", "A", -35, 30, 4.5, 2.5, 2.5, 0.6, 4800),
        L("Rim L", "A", -150, 25, 3.5, 0.4, 3.5, 1.5, "#8a4dff"),
        L("Rim R", "A", 150, 25, 3.5, 0.4, 3.5, 1.5, "#c34dff"),
    ]),
    ("CHIAROSCURO", "Chiaroscuro", "Luxury", "#000000", 0.0, [
        L("Key", "S", -75, 35, 4, 30, 0.4, 2.0, 4300),
        L("Bounce", "A", 60, 5, 5, 3, 3, 0.05, 4300),
    ]),
    ("GLASS_BACKLIT", "Glass Bottle Backlit", "Glass", "#080808", 0.03, [
        L("Back Panel", "A", 180, 22, 3.5, 2.2, 3.5, 2.2, 6500),
        L("Edge L", "A", -105, 10, 3, 0.25, 4.5, 1.6, 6500, 45),
        L("Edge R", "A", 105, 10, 3, 0.25, 4.5, 1.6, 6500, 45),
        L("Wall Glow", "B", 180, 0, 1.3, 80, 1.0, 3.0, 6500),
    ]),
    ("LIQUID_EDGES", "Liquid Edge Strips", "Glass", "#050505", 0.02, [
        L("Edge L", "A", -120, 15, 3, 0.2, 5, 2.0, 6500, 35),
        L("Edge R", "A", 120, 15, 3, 0.2, 5, 2.0, 6500, 35),
        L("Top", "A", 180, 70, 3, 1.5, 0.3, 1.3, 7000),
        L("Base Glow", "B", 180, 0, 1.2, 100, 1.0, 1.5, 6500),
    ]),
    ("PERFUME", "Perfume Prestige", "Glass", "#040404", 0.02, [
        L("Wall Glow", "B", 180, 0, 1.3, 70, 1.0, 4.0, 5000),
        L("Rim L", "A", -135, 25, 3.5, 0.3, 4, 1.6, 4500),
        L("Rim R", "A", 135, 25, 3.5, 0.3, 4, 1.6, 4500),
        L("Key Spot", "S", -20, 40, 5, 25, 0.5, 0.8, 5600),
    ]),
    ("DRINK_BACKLIT", "Drink Backlit Chill", "Glass", "#050a0c", 0.05, [
        L("Back", "A", 180, 15, 3.5, 2, 3.5, 2.5, 7000),
        L("Edge L", "A", -110, 15, 3, 0.25, 4, 1.4, 7500),
        L("Edge R", "A", 110, 15, 3, 0.25, 4, 1.4, 7500),
        L("Front", "A", 0, 25, 5, 2, 2, 0.25, 6000),
    ]),
    ("JEWEL_SPARKLE", "Jewellery Sparkle", "Jewellery", "#101010", 0.15, [
        L("Tent", "A", 0, 75, 4, 5, 5, 0.8, 6000),
        L("Spark 1", "P", -60, 35, 3, 0.02, 0, 0.7, 6500),
        L("Spark 2", "P", 50, 45, 3, 0.02, 0, 0.7, 6500),
        L("Spark 3", "P", 160, 30, 3, 0.02, 0, 0.6, 6500),
        L("Spark 4", "P", -140, 50, 3, 0.02, 0, 0.6, 6500),
        L("Spark 5", "P", 10, 20, 3, 0.02, 0, 0.5, 6500),
    ]),
    ("DIAMOND_TENT", "Diamond Light Tent", "Jewellery", "#f0f0f0", 0.6, [
        L("Top", "A", 0, 85, 4, 6, 6, 0.6, 6500),
        L("Left", "A", -90, 20, 4, 5, 4, 0.4, 6500),
        L("Right", "A", 90, 20, 4, 5, 4, 0.4, 6500),
        L("Spark A", "S", -30, 40, 4, 5, 0.1, 1.0, 6500),
        L("Spark B", "S", 40, 30, 4, 5, 0.1, 0.8, 6500),
    ]),
    ("PACKAGING_EVEN", "Packaging Flat Even", "Packaging", "#c8c8c8", 0.5, [
        L("Left", "A", -40, 25, 5, 5, 5, 0.8, 5600),
        L("Right", "A", 40, 25, 5, 5, 5, 0.8, 5600),
        L("Top", "A", 0, 70, 5, 5, 5, 0.4, 5600),
    ]),
    ("BOX_HERO", "Box Hero", "Packaging", "#181818", 0.15, [
        L("Key", "A", -45, 35, 4.5, 3, 3, 1.1, 5600),
        L("Fill", "A", 50, 20, 5, 3, 3, 0.35, 5800),
        L("Top", "A", 0, 80, 4, 3, 3, 0.5, 6000),
        L("Rim", "A", 160, 25, 4, 1, 3, 1.0, 6500),
    ]),
    ("TECH_SLEEK", "Tech Sleek", "Tech", "#05070a", 0.03, [
        L("Strip L", "A", -110, 20, 3.5, 0.3, 4, 1.8, 8000),
        L("Strip R", "A", 110, 20, 3.5, 0.3, 4, 1.8, 8000),
        L("Top", "A", 0, 60, 4, 3, 0.3, 0.8, 7000),
        L("Front", "A", 0, 15, 6, 2, 1, 0.12, 6500),
    ]),
    ("SCREEN_GLOW", "Screen Glow", "Tech", "#020408", 0.02, [
        L("Front", "A", 0, 20, 5, 3, 2, 0.5, 6500),
        L("Rim", "A", 165, 30, 4, 0.5, 3, 1.8, "#3d8bff"),
        L("Neon Tube", "N", -165, 0, 5, 3.0, 0.03, 2.5, "#3d8bff"),
    ]),
    ("MATTE_SOFT", "Matte Product Soft", "Tech", "#3a3a3a", 0.35, [
        L("Key", "A", -35, 40, 4.5, 4, 4, 0.9, 5600),
        L("Fill", "A", 50, 20, 5, 4, 4, 0.4, 5600),
        L("Rim", "A", 170, 35, 4, 2, 2, 0.8, 6500),
    ]),
    ("SNEAKER_HERO", "Sneaker Hero", "Apparel", "#101010", 0.08, [
        L("Key", "A", -60, 35, 4, 2.5, 2, 1.2, 5600),
        L("Rim", "A", 150, 30, 4, 0.6, 3, 1.8, 6500),
        L("Kicker", "A", 100, 10, 4, 0.5, 2, 0.8, 6000),
        L("Fill", "A", 20, 10, 6, 3, 2, 0.15, 5600),
    ]),
    ("CHROME_PANELS", "Chrome Reflections", "Metal", "#0a0a0a", 0.05, [
        L("Top", "A", 0, 75, 3.5, 6, 3, 0.9, 6500),
        L("Left", "A", -90, 20, 3.5, 1.5, 5, 1.0, 6500),
        L("Right", "A", 90, 20, 3.5, 1.5, 5, 1.0, 6500),
        L("Back", "A", 180, 25, 4, 4, 1, 0.8, 6500),
    ]),
    ("AUTO_STUDIO", "Automotive Studio", "Metal", "#1a1a1a", 0.1, [
        L("Overhead", "A", 0, 88, 4, 8, 4, 1.0, 6500),
        L("Floor Kick L", "A", -100, 5, 4, 4, 0.4, 0.5, 6500),
        L("Floor Kick R", "A", 100, 5, 4, 4, 0.4, 0.5, 6500),
    ]),
]

GLARE_NAMES = {
    "BLOOM": "Bloom",
    "FOG_GLOW": "Fog Glow",
    "STREAKS": "Streaks",
    "SIMPLE_STAR": "Simple Star",
    "GHOSTS": "Ghosts",
}

TONES = [
    ("None", "Base", "AgX with no contrast look"),
    ("AgX - Punchy", "Punchy", "Saturated, contrasty"),
    ("AgX - Very High Contrast", "Very High Contrast", ""),
    ("AgX - High Contrast", "High Contrast", ""),
    ("AgX - Medium High Contrast", "Medium High Contrast", ""),
    ("AgX - Base Contrast", "Base Contrast", ""),
    ("AgX - Medium Low Contrast", "Medium Low Contrast", ""),
    ("AgX - Low Contrast", "Low Contrast", ""),
    ("AgX - Very Low Contrast", "Very Low Contrast", ""),
    ("AgX - Greyscale", "Greyscale", ""),
]


def LOOK(glare="NONE", gs=0.0, gt=1.0, gz=0.6, streaks=4, angle=0.0, ch=0.0, vig=0.0, sat=1.0, con=0.0, bri=0.0,
         lift=(1, 1, 1), gamma=(1, 1, 1), gain=(1, 1, 1), sharp=0.0, tone="None", exp=0.0):
    return dict(glare=glare, gs=gs, gt=gt, gz=gz, streaks=streaks, angle=angle, ch=ch, vig=vig, sat=sat, con=con,
                bri=bri, lift=lift, gamma=gamma, gain=gain, sharp=sharp, tone=tone, exp=exp)


COMP_LOOKS = [
    ("NONE", "No Grade", "Basics", LOOK()),
    ("CLEAN_COMMERCIAL", "Clean Commercial", "Clean", LOOK("BLOOM", 0.15, 1.0, 0.5, vig=0.1, sat=1.05, con=5, sharp=0.1, tone="AgX - Base Contrast")),
    ("CLEAN_BRIGHT", "Clean Bright", "Clean", LOOK("BLOOM", 0.1, 1.0, 0.5, sat=1.0, bri=3, lift=(1.02, 1.02, 1.03), gain=(1.02, 1.02, 1.02), tone="AgX - Medium Low Contrast", exp=0.3)),
    ("NEUTRAL", "Neutral Natural", "Clean", LOOK(tone="None")),
    ("CRISP_DETAIL", "Crisp Detail", "Clean", LOOK(sharp=0.35, con=8, tone="AgX - Medium High Contrast")),
    ("MINIMAL", "Minimal White", "Clean", LOOK(con=4, exp=0.15, lift=(1.01, 1.01, 1.02), sharp=0.1, tone="AgX - Base Contrast")),
    ("BEAUTY_SOFT", "Beauty Soft", "Beauty", LOOK("FOG_GLOW", 0.25, 1.4, 0.7, vig=0.15, sat=0.95, con=-8, lift=(1.05, 1.03, 1.03), gain=(1.02, 1.0, 0.99), tone="AgX - Low Contrast")),
    ("BEAUTY_PASTEL", "Beauty Pastel", "Beauty", LOOK("FOG_GLOW", 0.15, 1.5, 0.6, vig=0.1, sat=0.9, con=-4, lift=(1.03, 1.01, 1.03), gain=(1.02, 0.99, 1.02), tone="AgX - Medium Low Contrast", exp=0.0)),
    ("DREAMY_BLOOM", "Dreamy Bloom", "Beauty", LOOK("BLOOM", 0.45, 1.2, 0.85, vig=0.2, sat=0.9, con=-5, tone="AgX - Low Contrast")),
    ("SOFT_PEACH", "Soft Peach", "Beauty", LOOK("FOG_GLOW", 0.15, 1.4, 0.6, sat=0.95, lift=(1.06, 1.02, 1.0), gamma=(1.02, 1.0, 0.97), gain=(1.04, 1.0, 0.95), tone="AgX - Medium Low Contrast")),
    ("DARK_EDITORIAL", "Dark Editorial", "Dark", LOOK("BLOOM", 0.12, 1.2, 0.5, vig=0.45, sat=0.85, con=15, bri=-4, lift=(0.97, 0.97, 0.98), tone="AgX - High Contrast", exp=-0.2)),
    ("MOODY_MATTE", "Moody Matte", "Dark", LOOK(vig=0.35, sat=0.75, con=-5, lift=(1.08, 1.08, 1.1), tone="AgX - Medium High Contrast", exp=-0.3)),
    ("NOIR_BW", "Noir Monochrome", "Dark", LOOK("BLOOM", 0.1, 1.0, 0.5, vig=0.5, sat=0.0, con=20, tone="AgX - Very High Contrast")),
    ("DEEP_CONTRAST", "Deep Contrast", "Dark", LOOK(vig=0.3, sat=1.1, con=25, tone="AgX - Very High Contrast")),
    ("LOWKEY_TEAL", "Low-Key Teal", "Dark", LOOK(vig=0.4, sat=0.9, con=10, lift=(0.95, 1.02, 1.05), gain=(1.02, 1.0, 0.97), tone="AgX - High Contrast", exp=-0.3)),
    ("METALLIC_CHROME", "Metallic Chrome", "Metallic", LOOK("STREAKS", 0.15, 1.3, 0.6, 4, 45, vig=0.25, sat=0.7, con=18, gain=(0.98, 1.0, 1.04), sharp=0.2, tone="AgX - High Contrast")),
    ("GOLD_LUXE", "Gold Luxe", "Metallic", LOOK("BLOOM", 0.3, 0.9, 0.6, vig=0.35, sat=1.05, con=10, lift=(1.0, 0.98, 0.94), gamma=(1.02, 1.0, 0.94), gain=(1.06, 1.0, 0.88), tone="AgX - Punchy")),
    ("STEEL_BLUE", "Steel Blue", "Metallic", LOOK(vig=0.25, sat=0.8, con=12, lift=(0.98, 1.0, 1.04), gain=(0.95, 1.0, 1.08), tone="AgX - Medium High Contrast")),
    ("NEON_GLOW", "Neon Glow", "Glow", LOOK("BLOOM", 0.45, 0.8, 0.7, ch=0.015, vig=0.35, sat=1.25, con=10, tone="AgX - Punchy")),
    ("GLOW_STREAKS", "Glow Streaks", "Glow", LOOK("STREAKS", 0.4, 0.8, 0.6, 6, 15, vig=0.2, sat=1.1, con=8)),
    ("STARBURST", "Starburst Sparkle", "Glow", LOOK("SIMPLE_STAR", 0.45, 0.9, 0.6, vig=0.25, con=10, sharp=0.2)),
    ("HALO_BLOOM", "Halo Bloom", "Glow", LOOK("FOG_GLOW", 0.35, 0.9, 0.8, vig=0.4, con=8, tone="AgX - High Contrast")),
    ("ANAMORPHIC", "Anamorphic Streak", "Glow", LOOK("STREAKS", 0.45, 0.85, 0.6, 2, 0, ch=0.01, vig=0.35, con=8, gain=(0.98, 1.0, 1.04), tone="AgX - Medium High Contrast")),
    ("PREMIUM", "Premium Commercial", "Premium", LOOK("BLOOM", 0.2, 1.0, 0.55, vig=0.25, sat=1.05, con=10, sharp=0.15, tone="AgX - Punchy")),
    ("LUXURY_WARM", "Luxury Warm", "Premium", LOOK("BLOOM", 0.25, 1.0, 0.6, vig=0.3, con=8, lift=(1.02, 1.0, 0.97), gain=(1.05, 1.0, 0.92), tone="AgX - Medium High Contrast")),
    ("TEAL_ORANGE", "Cinematic Teal-Orange", "Premium", LOOK(vig=0.3, sat=1.1, con=12, lift=(0.95, 1.0, 1.06), gain=(1.08, 1.0, 0.9), tone="AgX - Punchy")),
    ("COOL_TECH", "Cool Tech", "Premium", LOOK("BLOOM", 0.2, 1.0, 0.5, vig=0.2, sat=0.95, con=12, lift=(0.97, 1.0, 1.05), gain=(0.97, 1.0, 1.06), sharp=0.2, tone="AgX - High Contrast")),
    ("VIVID_POP", "Vivid Pop", "Premium", LOOK("BLOOM", 0.15, 1.0, 0.5, vig=0.1, sat=1.35, con=15, tone="AgX - Punchy", exp=0.1)),
    ("FILM_FADE", "Film Fade", "Film", LOOK(ch=0.004, vig=0.2, sat=0.85, con=-10, lift=(1.1, 1.08, 1.06), gain=(0.98, 0.98, 0.96), tone="AgX - Medium Low Contrast")),
    ("VINTAGE_WARM", "Vintage Warm", "Film", LOOK("FOG_GLOW", 0.15, 0.9, 0.6, ch=0.006, vig=0.4, sat=0.8, con=-5, lift=(1.08, 1.04, 0.98), gain=(1.06, 1.0, 0.88))),
    ("BLEACH_BYPASS", "Bleach Bypass", "Film", LOOK(vig=0.35, sat=0.45, con=28, sharp=0.15, tone="AgX - High Contrast", exp=-0.1)),
]

SHOTS = [
    ("HERO", "Hero 3/4", 35, 14, 65, 0.16, 0, 0.5, False, None),
    ("FRONT", "Front", 0, 4, 85, 0.14, 0, 0.5, False, None),
    ("SIDE", "Profile", 90, 4, 85, 0.14, 0, 0.5, False, None),
    ("BACK_34", "Back 3/4", 145, 14, 65, 0.16, 0, 0.5, False, None),
    ("LOW", "Low Angle", 30, -3, 35, 0.2, 0, 0.6, False, None),
    ("HIGH", "High Angle", 30, 40, 50, 0.18, 0, 0.5, False, None),
    ("TOP", "Top Down", 0, 89.5, 50, 0.2, 0, 0.5, False, None),
    ("MACRO", "Macro Detail", 30, 10, 100, 0.0, 0, 0.72, True, 2.8),
    ("WIDE", "Wide Establishing", 35, 12, 24, 0.55, 0, 0.5, False, None),
    ("DUTCH", "Dutch Hero", 35, 14, 50, 0.2, 12, 0.5, False, None),
]

ASPECTS = [
    ("16_9", "16:9 Landscape", 16, 9),
    ("9_16", "9:16 Reels / Stories", 9, 16),
    ("1_1", "1:1 Square", 1, 1),
    ("4_5", "4:5 Portrait Feed", 4, 5),
    ("4_3", "4:3 Classic", 4, 3),
    ("3_2", "3:2 Photo", 3, 2),
    ("2_3", "2:3 Poster", 2, 3),
    ("21_9", "21:9 Ultrawide", 21, 9),
    ("239_1", "2.39:1 Anamorphic", 2.39, 1),
    ("185_1", "1.85:1 Flat", 1.85, 1),
]

FINISHES = [
    ("MATTE", "Matte Paper", 0.85, 0.0, 0.0, 0.3, "none"),
    ("SATIN", "Satin", 0.38, 0.0, 0.0, 0.5, "none"),
    ("GLOSS", "Gloss Acrylic", 0.06, 0.0, 1.0, 0.5, "none"),
    ("MIRROR", "Mirror", 0.02, 1.0, 0.0, 0.5, "none"),
    ("WET", "Wet Surface", 0.12, 0.0, 0.6, 0.5, "wet"),
    ("CONCRETE", "Concrete", 0.75, 0.0, 0.0, 0.4, "concrete"),
    ("TERRAZZO", "Terrazzo", 0.3, 0.0, 0.3, 0.5, "terrazzo"),
    ("MARBLE", "Polished Marble", 0.12, 0.0, 0.4, 0.5, "marble"),
    ("BRUSHED", "Brushed Metal", 0.3, 1.0, 0.0, 0.5, "brushed"),
    ("VELVET", "Velvet", 0.9, 0.0, 0.0, 0.2, "velvet"),
]

RECIPES = [
    ("MINIMAL_WHITE", "Minimal White", dict(backdrop_type="CYC", gradient_type="SCREEN", color_a=(0.75, 0.75, 0.76), color_b=(0.95, 0.95, 0.95), floor_finish="SATIN", light_preset="HIGH_KEY", comp_look="MINIMAL", shot="HERO", backdrop_glow=0.0)),
    ("DARK_LUXURY", "Dark Luxury", dict(backdrop_type="DOME", gradient_type="SCREEN", color_a=(0.002, 0.002, 0.002), color_b=(0.03, 0.03, 0.03), floor_finish="GLOSS", light_preset="DARK_CONTOUR", comp_look="DARK_EDITORIAL", shot="LOW", backdrop_glow=0.0)),
    ("NEON_TECH", "Neon Tech", dict(backdrop_type="DOME", gradient_type="RADIAL", color_a=(0.0, 0.0, 0.003), color_b=(0.01, 0.006, 0.03), floor_finish="MIRROR", light_preset="NEON_CYBER", comp_look="NEON_GLOW", shot="HERO", backdrop_glow=0.0)),
    ("WARM_SUNSET", "Warm Sunset", dict(backdrop_type="CYC", gradient_type="VERTICAL", color_a=(0.9, 0.38, 0.2), color_b=(0.98, 0.7, 0.5), floor_finish="MATTE", light_preset="SUNSET", comp_look="LUXURY_WARM", shot="HERO", backdrop_glow=0.15)),
    ("PASTEL_BEAUTY", "Pastel Beauty", dict(backdrop_type="CYC", gradient_type="SCREEN", color_a=(0.75, 0.6, 0.85), color_b=(0.98, 0.8, 0.85), floor_finish="SATIN", light_preset="SOFT_BEAUTY", comp_look="BEAUTY_PASTEL", shot="HERO", backdrop_glow=0.1)),
    ("CONCRETE_INDUSTRIAL", "Concrete Industrial", dict(backdrop_type="CYC", gradient_type="VERTICAL", color_a=(0.12, 0.12, 0.12), color_b=(0.35, 0.34, 0.33), floor_finish="CONCRETE", light_preset="HARD_STRIPS", comp_look="METALLIC_CHROME", shot="LOW", backdrop_glow=0.35)),
    ("GOLD_PRESTIGE", "Gold Prestige", dict(backdrop_type="DOME", gradient_type="SCREEN", color_a=(0.0, 0.0, 0.0), color_b=(0.04, 0.02, 0.008), floor_finish="GLOSS", light_preset="GOLD_ACCENT", comp_look="GOLD_LUXE", shot="HERO", backdrop_glow=0.0)),
    ("GLASS_WATER", "Glass & Water", dict(backdrop_type="CYC", gradient_type="VERTICAL", color_a=(0.45, 0.62, 0.8), color_b=(0.9, 0.95, 1.0), floor_finish="SATIN", light_preset="GLASS_BACKLIT", comp_look="COOL_TECH", shot="FRONT", backdrop_glow=0.2)),
    ("BLACK_VELVET", "Black Velvet Jewellery", dict(backdrop_type="DOME", gradient_type="SOLID", color_a=(0.0, 0.0, 0.0), color_b=(0.004, 0.004, 0.004), floor_finish="VELVET", light_preset="JEWEL_SPARKLE", comp_look="STARBURST", shot="MACRO", backdrop_glow=0.0)),
    ("TERRAZZO_LIFESTYLE", "Terrazzo Lifestyle", dict(backdrop_type="CYC", gradient_type="SOLID", color_a=(0.8, 0.72, 0.62), color_b=(0.85, 0.78, 0.68), floor_finish="TERRAZZO", light_preset="WINDOW", comp_look="FILM_FADE", shot="HIGH", backdrop_glow=0.0)),
    ("BOLD_POP", "Bold Pop Colour", dict(backdrop_type="CYC", gradient_type="SCREEN", color_a=(0.85, 0.55, 0.0), color_b=(1.0, 0.8, 0.05), floor_finish="MATTE", light_preset="HIGH_KEY", comp_look="VIVID_POP", shot="HERO", backdrop_glow=0.2)),
    ("HALO_HERO", "Halo Hero", dict(backdrop_type="DOME", gradient_type="RADIAL", color_a=(0.0, 0.0, 0.0), color_b=(0.03, 0.03, 0.035), floor_finish="GLOSS", light_preset="HALO_RING", comp_look="HALO_BLOOM", shot="FRONT", backdrop_glow=0.0)),
    ("MARBLE_EDITORIAL", "Marble Editorial", dict(backdrop_type="CYC", gradient_type="VERTICAL", color_a=(0.6, 0.58, 0.55), color_b=(0.88, 0.86, 0.83), floor_finish="MARBLE", light_preset="WINDOW", comp_look="PREMIUM", shot="HERO", backdrop_glow=0.0)),
    ("CHROME_GARAGE", "Chrome Garage", dict(backdrop_type="DOME", gradient_type="VERTICAL", color_a=(0.01, 0.01, 0.012), color_b=(0.06, 0.06, 0.065), floor_finish="GLOSS", light_preset="AUTO_STUDIO", comp_look="STEEL_BLUE", shot="LOW", backdrop_glow=0.0)),
]

QUALITY = {
    "DRAFT": dict(cycles=32, eevee=16, percent=50, bounces=6),
    "PREVIEW": dict(cycles=128, eevee=32, percent=100, bounces=8),
    "FINAL": dict(cycles=512, eevee=96, percent=100, bounces=12),
    "ULTRA": dict(cycles=2048, eevee=256, percent=100, bounces=16),
}


def grouped_items(table, label_index=1, cat_index=2):
    items = []
    seen = None
    i = 0
    for row in table:
        cat = row[cat_index]
        if cat != seen:
            items.append(("", cat, ""))
            seen = cat
        items.append((row[0], row[label_index], cat, i))
        i += 1
    return items


def by_id(table, key):
    for row in table:
        if row[0] == key:
            return row
    return table[0]
