import os
from . import core
from .core import P
from .presets import ASPECTS, QUALITY, by_id


def apply_resolution(scene):
    p = P(scene)
    _, _, aw, ah = by_id(ASPECTS, p.aspect)
    short = int(p.resolution)
    if aw >= ah:
        h = short
        w = int(round(short * aw / ah / 2.0)) * 2
    else:
        w = short
        h = int(round(short * ah / aw / 2.0)) * 2
    r = scene.render
    r.resolution_x = w
    r.resolution_y = h
    r.pixel_aspect_x = 1.0
    r.pixel_aspect_y = 1.0


def apply_timing(scene):
    p = P(scene)
    r = scene.render
    r.fps = int(p.fps)
    r.fps_base = 1.0
    scene.frame_start = 1
    scene.frame_end = max(2, int(round(p.duration * int(p.fps))))
    if scene.frame_current > scene.frame_end:
        scene.frame_current = 1


def apply_engine(scene):
    p = P(scene)
    scene.render.engine = "CYCLES" if p.engine == "CYCLES" else core.eevee_id()
    from . import studio
    studio.sync_engine_visibility(scene)


def apply_quality(scene):
    p = P(scene)
    q = QUALITY[p.quality]
    r = scene.render
    r.resolution_percentage = q["percent"]
    cy = getattr(scene, "cycles", None)
    if cy is not None:
        cy.samples = q["cycles"]
        cy.preview_samples = min(64, q["cycles"])
        cy.use_adaptive_sampling = True
        cy.use_denoising = True
        cy.use_preview_denoising = True
        try:
            cy.denoiser = "OPENIMAGEDENOISE"
        except TypeError:
            pass
        cy.max_bounces = q["bounces"]
        cy.glossy_bounces = min(q["bounces"], 8)
        cy.transmission_bounces = q["bounces"]
        cy.caustics_reflective = False
        cy.caustics_refractive = False
        cy.film_transparent_glass = True
    ee = scene.eevee
    ee.taa_render_samples = q["eevee"]
    if hasattr(ee, "use_raytracing"):
        ee.use_raytracing = p.quality in {"FINAL", "ULTRA"} or p.quality == "PREVIEW"
    if hasattr(ee, "use_shadows"):
        ee.use_shadows = True
    if hasattr(ee, "use_gtao"):
        ee.use_gtao = True


def apply_film(scene):
    p = P(scene)
    r = scene.render
    r.film_transparent = p.film_transparent
    r.use_motion_blur = p.motion_blur
    r.motion_blur_shutter = p.shutter


def apply_output(scene):
    p = P(scene)
    r = scene.render
    ims = r.image_settings
    if p.output_format == "MP4":
        if hasattr(ims, "media_type"):
            ims.media_type = "VIDEO"
        ims.file_format = "FFMPEG"
        ff = r.ffmpeg
        ff.format = "MPEG4"
        ff.codec = "H264"
        ff.constant_rate_factor = "HIGH"
        ff.ffmpeg_preset = "GOOD"
        ff.audio_codec = "NONE"
    else:
        if hasattr(ims, "media_type"):
            ims.media_type = "IMAGE"
        ims.file_format = p.output_format
        if p.output_format == "PNG":
            ims.color_mode = "RGBA" if p.film_transparent else "RGB"
            ims.color_depth = "16" if p.quality in {"FINAL", "ULTRA"} else "8"
        else:
            ims.color_mode = "RGB"
            ims.quality = 95
    folder = p.output_dir or "//renders/"
    r.filepath = os.path.join(folder, (p.output_name or "product") + "_")


def apply_all(scene):
    apply_resolution(scene)
    apply_timing(scene)
    apply_engine(scene)
    apply_quality(scene)
    apply_film(scene)
    apply_output(scene)
