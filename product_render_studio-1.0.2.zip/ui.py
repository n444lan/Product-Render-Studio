import bpy
from . import core
from .core import P
from .presets import PRODUCT_ANIMS, CAMERA_ANIMS

ORBIT_ANIMS = {"ORBIT_360", "ORBIT_HALF", "WHIP_ORBIT", "SPIRAL_DOWN", "FLY_OVER"}


class SR_PT_base:
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Product Render Studio"


def cycler(layout, p, attr, target):
    row = layout.row(align=True)
    row.prop(p, attr, text="")
    op = row.operator("product_render_studio.cycle", text="", icon="TRIA_LEFT")
    op.target = target
    op.step = -1
    op = row.operator("product_render_studio.cycle", text="", icon="TRIA_RIGHT")
    op.target = target
    op.step = 1
    return row


class SR_PT_main(SR_PT_base, bpy.types.Panel):
    bl_label = "Product Render Studio"
    bl_idname = "SR_PT_main"

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        p = P(scene)
        box = layout.box()
        root = core.product_root(scene)
        if root is None:
            box.label(text="No product prepared", icon="INFO")
            box.label(text="Select your model, then Build Scene")
        else:
            box.label(text="Product ready", icon="CHECKMARK")
            box.label(text="Size %.1f x %.1f x %.1f cm" % (p.prod_w * 100, p.prod_d * 100, p.prod_h * 100))
        col = layout.column(align=True)
        col.scale_y = 1.6
        col.operator("product_render_studio.quick_build", icon="SHADERFX")
        layout.label(text="Recipe")
        row = cycler(layout, p, "recipe", "RECIPE")
        layout.operator("product_render_studio.apply_recipe", icon="BRUSHES_ALL")
        row = layout.row(align=True)
        row.operator("product_render_studio.view_camera", text="Camera View", icon="VIEW_CAMERA").rendered = False
        row.operator("product_render_studio.view_camera", text="Rendered", icon="SHADING_RENDERED").rendered = True


class SR_PT_prepare(SR_PT_base, bpy.types.Panel):
    bl_label = "1  Prepare"
    bl_parent_id = "SR_PT_main"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        self.layout.label(text="", icon="PACKAGE")

    def draw(self, context):
        layout = self.layout
        p = P(context.scene)
        col = layout.column(align=True)
        col.prop(p, "prep_ground")
        col.prop(p, "prep_center")
        col.prop(p, "prep_apply_scale")
        col.prop(p, "prep_smooth")
        row = layout.row(align=True)
        row.prop(p, "prep_normalize", text="")
        sub = row.row(align=True)
        sub.active = p.prep_normalize
        sub.prop(p, "prep_size")
        row = layout.row(align=True)
        row.scale_y = 1.3
        row.operator("product_render_studio.prepare", icon="CHECKMARK")
        row.operator("product_render_studio.release", text="", icon="X")


class SR_PT_studio(SR_PT_base, bpy.types.Panel):
    bl_label = "2  Studio"
    bl_parent_id = "SR_PT_main"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        self.layout.label(text="", icon="WORLD")

    def draw(self, context):
        layout = self.layout
        p = P(context.scene)
        layout.prop(p, "backdrop_type", expand=False)
        if p.backdrop_type == "CYC":
            col = layout.column(align=True)
            col.prop(p, "backdrop_scale")
            col.prop(p, "cyc_curve")
            row = layout.row(align=True)
            row.prop(p, "cyc_face_camera", toggle=True)
            row.prop(p, "backdrop_rotation", text="")
            if p.camera_anim in ORBIT_ANIMS:
                layout.label(text="Tip: 360 Studio suits orbit moves", icon="INFO")
        elif p.backdrop_type == "DOME":
            layout.prop(p, "backdrop_scale")
        elif p.backdrop_type == "IMAGE":
            layout.prop(p, "image_path", text="")
            row = layout.row(align=True)
            row.prop(p, "image_fit", expand=True)
            layout.prop(p, "image_strength")
            layout.prop(p, "image_light")
            layout.prop(p, "image_floor")
            if p.image_floor == "SHADOW" and p.engine == "EEVEE":
                layout.label(text="Shadow catcher needs Cycles", icon="ERROR")
        if p.backdrop_type in {"CYC", "DOME"}:
            box = layout.box()
            box.label(text="Gradient", icon="NODE_TEXTURE")
            box.prop(p, "gradient_type", text="")
            row = box.row(align=True)
            row.prop(p, "color_a", text="")
            row.prop(p, "color_b", text="")
            if p.gradient_type != "SOLID":
                col = box.column(align=True)
                col.prop(p, "gradient_position")
                col.prop(p, "gradient_softness")
            box.prop(p, "backdrop_glow")
            box = layout.box()
            box.label(text="Floor Styling", icon="MATERIAL")
            box.prop(p, "floor_finish", text="")
            box.prop(p, "floor_roughness")
        box = layout.box()
        box.label(text="Podium", icon="MESH_CYLINDER")
        box.prop(p, "podium_type", text="")
        if p.podium_type != "NONE":
            col = box.column(align=True)
            col.prop(p, "podium_height")
            col.prop(p, "podium_padding")
            row = box.row(align=True)
            row.prop(p, "podium_color", text="")
            row.prop(p, "podium_finish", text="")
        layout.prop(p, "lock_studio")
        row = layout.row()
        row.scale_y = 1.3
        row.operator("product_render_studio.build_studio", icon="FILE_REFRESH")


class SR_PT_lighting(SR_PT_base, bpy.types.Panel):
    bl_label = "3  Lighting"
    bl_parent_id = "SR_PT_main"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        self.layout.label(text="", icon="LIGHT_AREA")

    def draw(self, context):
        layout = self.layout
        p = P(context.scene)
        cycler(layout, p, "light_preset", "LIGHT")
        col = layout.column(align=True)
        col.prop(p, "light_intensity")
        col.prop(p, "light_temperature")
        col.prop(p, "light_size")
        col.prop(p, "light_distance")
        col.prop(p, "light_rotation")
        layout.prop(p, "light_follow_camera")
        layout.prop(p, "flag_backlights")
        box = layout.box()
        box.label(text="Environment", icon="WORLD_DATA")
        row = box.row(align=True)
        row.prop(p, "world_color", text="")
        row.prop(p, "world_strength", text="Strength")
        box.prop(p, "hdri_path", text="")
        if p.hdri_path:
            box.prop(p, "hdri_rotation")
            box.prop(p, "hdri_hide")
        row = layout.row(align=True)
        row.scale_y = 1.3
        row.operator("product_render_studio.build_lights", icon="LIGHT")
        op = row.operator("product_render_studio.select", text="", icon="RESTRICT_SELECT_OFF")
        op.what = "LIGHTS"


class SR_PT_camera(SR_PT_base, bpy.types.Panel):
    bl_label = "4  Camera"
    bl_parent_id = "SR_PT_main"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        self.layout.label(text="", icon="CAMERA_DATA")

    def draw(self, context):
        layout = self.layout
        p = P(context.scene)
        cycler(layout, p, "shot", "SHOT")
        row = layout.row(align=True)
        row.prop(p, "aspect", text="")
        row.prop(p, "resolution", text="")
        col = layout.column(align=True)
        col.prop(p, "focal_length")
        col.prop(p, "frame_padding")
        if p.shot == "MACRO":
            col.prop(p, "macro_zoom")
        col = layout.column(align=True)
        col.prop(p, "cam_azimuth")
        col.prop(p, "cam_elevation")
        col.prop(p, "aim_height")
        row = layout.row(align=True)
        row.prop(p, "cam_roll")
        row.prop(p, "cam_tilt")
        row = layout.row(align=True)
        row.prop(p, "frame_offset_x")
        row.prop(p, "frame_offset_y")
        box = layout.box()
        box.prop(p, "use_dof")
        sub = box.column(align=True)
        sub.active = p.use_dof
        sub.prop(p, "fstop")
        sub.prop(p, "focus_offset")
        layout.prop(p, "show_thirds")
        row = layout.row(align=True)
        row.scale_y = 1.3
        row.operator("product_render_studio.build_camera", icon="CAMERA_DATA")
        row.operator("product_render_studio.select", text="", icon="RESTRICT_SELECT_OFF").what = "RIG"


class SR_PT_animate(SR_PT_base, bpy.types.Panel):
    bl_label = "5  Animate"
    bl_parent_id = "SR_PT_main"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        self.layout.label(text="", icon="ANIM")

    def draw(self, context):
        layout = self.layout
        p = P(context.scene)
        layout.label(text="Product  (%d)" % (len(PRODUCT_ANIMS) - 1))
        cycler(layout, p, "product_anim", "PRODUCT")
        layout.prop(p, "anim_strength", slider=False)
        layout.label(text="Camera  (%d)" % (len(CAMERA_ANIMS) - 1))
        cycler(layout, p, "camera_anim", "CAMERA")
        layout.prop(p, "cam_anim_strength")
        box = layout.box()
        box.label(text="Timing", icon="TIME")
        row = box.row(align=True)
        row.prop(p, "fps", text="")
        row.prop(p, "duration")
        row = box.row(align=True)
        row.prop(p, "hold_start")
        row.prop(p, "hold_end")
        box.prop(p, "seamless_loop")
        row = box.row(align=True)
        row.prop(p, "motion_blur", toggle=True)
        sub = row.row(align=True)
        sub.active = p.motion_blur
        sub.prop(p, "shutter")
        layout.prop(p, "auto_apply")
        row = layout.row(align=True)
        row.scale_y = 1.3
        row.operator("product_render_studio.apply_anim", icon="PLAY")
        row.operator("product_render_studio.clear_anim", text="", icon="TRASH")
        if core.product_root(context.scene) is None:
            layout.label(text="Prepare a product to animate it", icon="INFO")


class SR_PT_look(SR_PT_base, bpy.types.Panel):
    bl_label = "6  Look"
    bl_parent_id = "SR_PT_main"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        self.layout.label(text="", icon="NODE_COMPOSITING")

    def draw(self, context):
        layout = self.layout
        p = P(context.scene)
        layout.prop(p, "use_look")
        cycler(layout, p, "comp_look", "LOOK")
        layout.prop(p, "comp_intensity", slider=True)
        col = layout.column()
        col.active = p.use_look
        box = col.box()
        box.label(text="Glow", icon="LIGHT_SUN")
        box.prop(p, "comp_glare_type", text="")
        if p.comp_glare_type != "NONE":
            c = box.column(align=True)
            c.prop(p, "comp_glare_strength")
            c.prop(p, "comp_glare_threshold")
            if p.comp_glare_type in {"BLOOM", "FOG_GLOW"}:
                c.prop(p, "comp_glare_size")
            if p.comp_glare_type == "STREAKS":
                c.prop(p, "comp_streaks")
                c.prop(p, "comp_streak_angle")
        box = col.box()
        box.label(text="Grade", icon="COLOR")
        row = box.row(align=True)
        row.prop(p, "comp_lift", text="")
        row.prop(p, "comp_gamma", text="")
        row.prop(p, "comp_gain", text="")
        c = box.column(align=True)
        c.prop(p, "comp_saturation")
        c.prop(p, "comp_contrast")
        c.prop(p, "comp_brightness")
        box = col.box()
        box.label(text="Lens", icon="CAMERA_DATA")
        c = box.column(align=True)
        c.prop(p, "comp_vignette")
        c.prop(p, "comp_chroma")
        c.prop(p, "comp_sharpen")
        box = layout.box()
        box.label(text="Tone", icon="IMAGE_RGB")
        box.prop(p, "comp_tone", text="")
        box.prop(p, "comp_exposure")
        row = layout.row()
        row.scale_y = 1.3
        row.operator("product_render_studio.apply_look", icon="NODE_COMPOSITING")


class SR_PT_render(SR_PT_base, bpy.types.Panel):
    bl_label = "7  Render"
    bl_parent_id = "SR_PT_main"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        self.layout.label(text="", icon="RENDER_STILL")

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        p = P(scene)
        row = layout.row(align=True)
        row.prop(p, "engine", expand=True)
        row = layout.row(align=True)
        row.prop(p, "quality", expand=True)
        layout.prop(p, "film_transparent")
        if p.film_transparent and p.output_format == "MP4":
            layout.label(text="MP4 has no alpha: use PNG", icon="ERROR")
        layout.prop(p, "output_format", text="")
        layout.prop(p, "output_dir", text="")
        layout.prop(p, "output_name")
        r = scene.render
        layout.label(text="%d x %d  ·  %d frames @ %s fps" % (
            r.resolution_x * r.resolution_percentage // 100, r.resolution_y * r.resolution_percentage // 100,
            scene.frame_end - scene.frame_start + 1, p.fps))
        col = layout.column(align=True)
        col.scale_y = 1.4
        col.operator("product_render_studio.render_still", icon="RENDER_STILL")
        col.operator("product_render_studio.render_anim", icon="RENDER_ANIMATION")


class SR_PT_scene(SR_PT_base, bpy.types.Panel):
    bl_label = "Scene Tools"
    bl_parent_id = "SR_PT_main"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        self.layout.label(text="", icon="TOOL_SETTINGS")

    def draw(self, context):
        layout = self.layout
        grid = layout.grid_flow(columns=2, align=True)
        for what, icon in (("PRODUCT", "OBJECT_DATA"), ("LIGHTS", "LIGHT"), ("CAMERA", "CAMERA_DATA"),
                           ("FOCUS", "CON_OBJECTSOLVER"), ("BACKDROP", "MESH_PLANE"), ("PODIUM", "MESH_CYLINDER")):
            grid.operator("product_render_studio.select", text=what.title(), icon=icon).what = what
        layout.separator()
        layout.operator("product_render_studio.remove", icon="TRASH")


classes = (
    SR_PT_main,
    SR_PT_prepare,
    SR_PT_studio,
    SR_PT_lighting,
    SR_PT_camera,
    SR_PT_animate,
    SR_PT_look,
    SR_PT_render,
    SR_PT_scene,
)


def register():
    for c in classes:
        bpy.utils.register_class(c)


def unregister():
    for c in reversed(classes):
        bpy.utils.unregister_class(c)
