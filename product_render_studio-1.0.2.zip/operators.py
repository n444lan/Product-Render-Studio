import bpy
from bpy.props import EnumProperty, IntProperty
from . import core, prepare, studio, lighting, camera, animation, look, render, props
from .core import P
from .presets import RECIPES, LIGHT_PRESETS, PRODUCT_ANIMS, CAMERA_ANIMS, COMP_LOOKS, SHOTS, by_id


def build_everything(context, report=None):
    scene = context.scene
    with core.locked():
        render.apply_all(scene)
        studio.build_studio(scene)
        lighting.build_lights(scene)
        camera.apply_camera(scene, rebuild_anim=False)
        studio.build_world(scene)
        animation.apply_all(scene)
        look.apply(scene)
    camera.look_through(context)


class SR_OT_prepare(bpy.types.Operator):
    bl_idname = "product_render_studio.prepare"
    bl_label = "Prepare Product"
    bl_description = "Group the selected objects into an animatable product rig, grounded and centred"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return context.mode == "OBJECT" and any(o.get("sr_role") is None for o in context.selected_objects)

    def execute(self, context):
        root = prepare.prepare(context, context.selected_objects)
        if root is None:
            self.report({"WARNING"}, "Select at least one mesh to use as the product")
            return {"CANCELLED"}
        scene = context.scene
        with core.locked():
            if core.first(scene, "stage") is not None:
                studio.build_studio(scene)
            if core.first(scene, "light_rig") is not None:
                lighting.build_lights(scene)
            if core.first(scene, "camera") is not None:
                camera.apply_camera(scene)
        self.report({"INFO"}, "Product ready: %d object(s)" % len(prepare.product_objects(scene)))
        return {"FINISHED"}


class SR_OT_release(bpy.types.Operator):
    bl_idname = "product_render_studio.release"
    bl_label = "Release Product"
    bl_description = "Remove the product rig and its animation, leaving the objects where they stand"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return core.product_root(context.scene) is not None

    def execute(self, context):
        n = prepare.release(context.scene)
        self.report({"INFO"}, "Released %d object(s)" % n)
        return {"FINISHED"}


class SR_OT_quick_build(bpy.types.Operator):
    bl_idname = "product_render_studio.quick_build"
    bl_label = "Build Scene"
    bl_description = "Prepare the selection (if needed) and build studio, lighting, camera, animation, look and render settings in one go"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        scene = context.scene
        if core.product_root(scene) is None:
            sel = [o for o in context.selected_objects if o.get("sr_role") is None]
            if sel:
                prepare.prepare(context, sel)
            else:
                self.report({"WARNING"}, "No product prepared: building around the origin. Select your model and press Prepare Product")
        build_everything(context)
        return {"FINISHED"}


class SR_OT_build_studio(bpy.types.Operator):
    bl_idname = "product_render_studio.build_studio"
    bl_label = "Build Studio"
    bl_description = "Create or rebuild the backdrop, floor and podium"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        with core.locked():
            studio.build_studio(context.scene)
            if core.first(context.scene, "light_rig") is not None:
                lighting.update_lights(context.scene)
        return {"FINISHED"}


class SR_OT_build_lights(bpy.types.Operator):
    bl_idname = "product_render_studio.build_lights"
    bl_label = "Light Product"
    bl_description = "Create the selected lighting preset, scaled to the product"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        with core.locked():
            props.populate_light(P(context.scene))
            lighting.build_lights(context.scene)
        return {"FINISHED"}


class SR_OT_build_camera(bpy.types.Operator):
    bl_idname = "product_render_studio.build_camera"
    bl_label = "Frame Product"
    bl_description = "Create or update the camera and frame the product for the selected shot"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        with core.locked():
            camera.apply_camera(context.scene)
        camera.look_through(context)
        return {"FINISHED"}


class SR_OT_apply_anim(bpy.types.Operator):
    bl_idname = "product_render_studio.apply_anim"
    bl_label = "Apply Animation"
    bl_description = "Key the selected product and camera animation presets"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        scene = context.scene
        with core.locked():
            render.apply_timing(scene)
            if core.first(scene, "camera") is None:
                camera.apply_camera(scene, rebuild_anim=False)
            animation.apply_all(scene)
        if core.product_root(scene) is None and P(scene).product_anim != "NONE":
            self.report({"WARNING"}, "Prepare a product to animate it")
        return {"FINISHED"}


class SR_OT_clear_anim(bpy.types.Operator):
    bl_idname = "product_render_studio.clear_anim"
    bl_label = "Clear Animation"
    bl_description = "Remove product and camera animation created by Product Render Studio"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        p = P(context.scene)
        with core.locked():
            p.product_anim = "NONE"
            p.camera_anim = "STATIC"
            animation.clear_all(context.scene)
        return {"FINISHED"}


class SR_OT_apply_look(bpy.types.Operator):
    bl_idname = "product_render_studio.apply_look"
    bl_label = "Apply Look"
    bl_description = "Build the compositing grade and colour management"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        with core.locked():
            P(context.scene).use_look = True
            look.apply(context.scene)
        return {"FINISHED"}


class SR_OT_apply_recipe(bpy.types.Operator):
    bl_idname = "product_render_studio.apply_recipe"
    bl_label = "Apply Recipe"
    bl_description = "Apply a complete art direction: backdrop, floor, lighting, shot and grade"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        scene = context.scene
        p = P(scene)
        data = by_id(RECIPES, p.recipe)[2]
        with core.locked():
            for k, v in data.items():
                setattr(p, k, v)
            props.populate_light(p)
            props.populate_look(p)
            props.populate_finish(p)
            props.populate_shot(p)
        build_everything(context)
        return {"FINISHED"}


CYCLE_TABLES = {
    "LIGHT": ("light_preset", LIGHT_PRESETS),
    "PRODUCT": ("product_anim", PRODUCT_ANIMS),
    "CAMERA": ("camera_anim", CAMERA_ANIMS),
    "LOOK": ("comp_look", COMP_LOOKS),
    "SHOT": ("shot", SHOTS),
    "RECIPE": ("recipe", RECIPES),
}


class SR_OT_cycle(bpy.types.Operator):
    bl_idname = "product_render_studio.cycle"
    bl_label = "Next Preset"
    bl_description = "Step through presets"
    bl_options = {"REGISTER", "UNDO"}

    target: EnumProperty(items=[(k, k.title(), "") for k in CYCLE_TABLES])
    step: IntProperty(default=1)

    def execute(self, context):
        p = P(context.scene)
        attr, table = CYCLE_TABLES[self.target]
        ids = [r[0] for r in table]
        cur = getattr(p, attr)
        i = ids.index(cur) if cur in ids else 0
        setattr(p, attr, ids[(i + self.step) % len(ids)])
        if self.target == "RECIPE":
            bpy.ops.product_render_studio.apply_recipe()
        return {"FINISHED"}


class SR_OT_view_camera(bpy.types.Operator):
    bl_idname = "product_render_studio.view_camera"
    bl_label = "Look Through Camera"
    bl_description = "View through the studio camera"

    rendered: bpy.props.BoolProperty(default=False)

    def execute(self, context):
        if not camera.look_through(context):
            self.report({"WARNING"}, "Frame the product first")
            return {"CANCELLED"}
        if self.rendered:
            camera.set_shading(context, "RENDERED")
        return {"FINISHED"}


class SR_OT_render_still(bpy.types.Operator):
    bl_idname = "product_render_studio.render_still"
    bl_label = "Render Still"
    bl_description = "Render the current frame"

    def execute(self, context):
        scene = context.scene
        if scene.camera is None:
            self.report({"WARNING"}, "No camera")
            return {"CANCELLED"}
        bpy.ops.render.render("INVOKE_DEFAULT")
        return {"FINISHED"}


class SR_OT_render_anim(bpy.types.Operator):
    bl_idname = "product_render_studio.render_anim"
    bl_label = "Render Animation"
    bl_description = "Render the full frame range to the output folder"

    def execute(self, context):
        scene = context.scene
        if scene.camera is None:
            self.report({"WARNING"}, "No camera")
            return {"CANCELLED"}
        render.apply_output(scene)
        bpy.ops.render.render("INVOKE_DEFAULT", animation=True)
        return {"FINISHED"}


SELECT_ROLES = {
    "LIGHTS": ("light", "halo", "neon"),
    "CAMERA": ("camera",),
    "RIG": ("cam_rig",),
    "FOCUS": ("focus",),
    "BACKDROP": ("backdrop", "floor", "catcher"),
    "PODIUM": ("podium",),
    "PRODUCT": ("product_spin",),
}


class SR_OT_select(bpy.types.Operator):
    bl_idname = "product_render_studio.select"
    bl_label = "Select"
    bl_description = "Select generated studio objects for manual art direction"
    bl_options = {"REGISTER", "UNDO"}

    what: EnumProperty(items=[(k, k.title(), "") for k in SELECT_ROLES])

    def execute(self, context):
        if context.mode != "OBJECT":
            return {"CANCELLED"}
        vl = context.view_layer
        objs = [o for o in core.tagged(context.scene, *SELECT_ROLES[self.what]) if o.name in vl.objects]
        if not objs:
            self.report({"WARNING"}, "Nothing to select yet")
            return {"CANCELLED"}
        for o in vl.objects:
            o.select_set(False)
        for o in objs:
            o.hide_select = False
            o.select_set(True)
        vl.objects.active = objs[0]
        return {"FINISHED"}


class SR_OT_remove(bpy.types.Operator):
    bl_idname = "product_render_studio.remove"
    bl_label = "Remove Studio"
    bl_description = "Delete the generated studio, lights, camera and grade. The product is kept"
    bl_options = {"REGISTER", "UNDO"}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        scene = context.scene
        p = P(scene)
        animation.reset_product(scene)
        core.remove_roles(scene, *studio.STAGE_ROLES, *lighting.LIGHT_ROLES, *camera.CAM_ROLES)
        for name in list(bpy.data.materials.keys()):
            mat = bpy.data.materials[name]
            if name.startswith("SR ") and mat.users == 0:
                bpy.data.materials.remove(mat)
        fc = bpy.data.collections.get(lighting.FLAG_COLL)
        if fc is not None:
            bpy.data.collections.remove(fc)
        w = bpy.data.worlds.get("SR World")
        if scene.world is w and w is not None:
            prev = bpy.data.worlds.get(p.prev_world) if p.prev_world else None
            scene.world = prev
        if w is not None and w.users == 0:
            bpy.data.worlds.remove(w)
        with core.locked():
            p.use_look = False
        look.attach(scene, False)
        if core.V5:
            ng = bpy.data.node_groups.get(look.TREE_NAME)
            if ng is not None and ng.users == 0:
                bpy.data.node_groups.remove(ng)
        for name in core.SUB_COLLS.values():
            c = bpy.data.collections.get(name)
            if c is not None and not c.objects and name != core.SUB_COLLS["product"]:
                bpy.data.collections.remove(c)
        return {"FINISHED"}


classes = (
    SR_OT_prepare,
    SR_OT_release,
    SR_OT_quick_build,
    SR_OT_build_studio,
    SR_OT_build_lights,
    SR_OT_build_camera,
    SR_OT_apply_anim,
    SR_OT_clear_anim,
    SR_OT_apply_look,
    SR_OT_apply_recipe,
    SR_OT_cycle,
    SR_OT_view_camera,
    SR_OT_render_still,
    SR_OT_render_anim,
    SR_OT_select,
    SR_OT_remove,
)


def register():
    for c in classes:
        bpy.utils.register_class(c)


def unregister():
    for c in reversed(classes):
        bpy.utils.unregister_class(c)
